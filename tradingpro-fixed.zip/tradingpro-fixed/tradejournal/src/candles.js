'use strict';
/**
 * Candle / OHLCV provider layer.
 *
 * The Market Mechanics bots are price-action bots: they need real OHLC bars,
 * not the single quote tick that the journal's market overview uses. This
 * module hides the provider zoo behind one function:
 *
 *     const { candles, meta } = await getCandles('XAUUSD', '15m', { limit: 600 });
 *
 * Providers (all free, no API key, chosen because they answer from arbitrary hosts):
 *   - OKX public candles   -> crypto, best intraday granularity, always current
 *   - Yahoo Finance chart  -> forex / indices / futures / stocks / ETFs  (=X, ^, =F)
 *   - CoinGecko OHLC       -> crypto fallback when OKX is unreachable (4h only)
 *
 * Guarantees the callers rely on:
 *   - bars are sorted oldest -> newest
 *   - every bar has finite o/h/l/c, high >= max(o,c), low <= min(o,c)
 *   - the newest bar may still be forming; meta.last_bar_closed tells the caller
 *   - results are cached per (symbol, timeframe) with a timeframe-aware TTL
 */

const { YAHOO_MAP, COINGECKO_IDS } = require('./market');
const B = require('./instruments');

/* ------------------------------------------------------------------ timeframes */

/**
 * tf -> provider mapping. `yahooRange` is the largest range Yahoo answers for
 * that interval; `agg` means "fetch `base` then aggregate by `factor`".
 */
const TIMEFRAMES = {
  '1m': { ms: 60e3, yahoo: '1m', yahooRange: '7d', okx: '1m', ttl: 25, label: '1 minute' },
  '3m': { ms: 180e3, yahoo: null, yahooRange: null, okx: '3m', ttl: 40, label: '3 minutes' },
  '5m': { ms: 300e3, yahoo: '5m', yahooRange: '1mo', okx: '5m', ttl: 45, label: '5 minutes' },
  '15m': { ms: 900e3, yahoo: '15m', yahooRange: '60d', okx: '15m', ttl: 60, label: '15 minutes' },
  '30m': { ms: 1800e3, yahoo: '30m', yahooRange: '60d', okx: '30m', ttl: 120, label: '30 minutes' },
  '1h': { ms: 3600e3, yahoo: '1h', yahooRange: '730d', okx: '1H', ttl: 180, label: '1 hour' },
  '4h': { ms: 4 * 3600e3, yahoo: null, yahooRange: null, yahooFrom: '1h', agg: 4, okx: '4H', ttl: 300, label: '4 hours' },
  '1d': { ms: 864e5, yahoo: '1d', yahooRange: '2y', okx: '1D', ttl: 900, label: '1 day' },
  '1w': { ms: 7 * 864e5, yahoo: '1wk', yahooRange: '5y', okx: '1W', ttl: 3600, label: '1 week' },
};
const TF_KEYS = Object.keys(TIMEFRAMES);
const DEFAULT_TF = '15m';

/** Timeframes a user can pick for a chart, in display order. */
const CHART_TFS = ['1m', '3m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'];

function tfInfo(tf) {
  const key = TIMEFRAMES[tf] ? tf : DEFAULT_TF;
  return { key, ...TIMEFRAMES[key] };
}

/* ------------------------------------------------------------------ symbols */

const CRYPTO_YAHOO = {
  BTCUSDT: 'BTC-USD', ETHUSDT: 'ETH-USD', SOLUSDT: 'SOL-USD', BNBUSDT: 'BNB-USD',
  XRPUSDT: 'XRP-USD', ADAUSDT: 'ADA-USD', DOGEUSDT: 'DOGE-USD', LINKUSDT: 'LINK-USD',
  BTCUSD: 'BTC-USD', ETHUSD: 'ETH-USD', SOLUSD: 'SOL-USD', BTCUSDC: 'BTC-USD', ETHUSDC: 'ETH-USD',
  XAUUSDT: 'GOLD-USD',
};

const isCryptoSymbol = (s) => !!(COINGECKO_IDS[s] || CRYPTO_YAHOO[s] || /USDT$/.test(s));

/** Base/quote split for a crypto symbol, e.g. BTCUSDT -> {base:'BTC', quote:'USDT'} */
function cryptoSplit(sym) {
  const m = /^([A-Z0-9]{2,6}?)(USDT|USDC|USD|BTC|ETH)$/.exec(sym);
  if (m) return { base: m[1], quote: m[2] };
  return { base: sym.replace(/(USDT|USDC|USD)$/, '') || sym, quote: 'USD' };
}

/**
 * Work out how to fetch a journal instrument symbol.
 * @returns {{symbol:string, provider:'okx'|'yahoo'|'coingecko', ticker:string, note:string, assetClass:string}}
 */
function resolveSymbol(symbol) {
  const sym = String(symbol || '').trim().toUpperCase();
  const spec = B.PRESETS.find((p) => p.symbol === sym);
  const assetClass = spec ? spec.asset_class : isCryptoSymbol(sym) ? 'crypto' : 'stocks';

  if (isCryptoSymbol(sym)) {
    const { base, quote } = cryptoSplit(sym);
    const q = quote === 'USDC' ? 'USDC' : 'USDT';
    return {
      symbol: sym, provider: 'okx', ticker: `${base}-${q}`,
      fallback: CRYPTO_YAHOO[sym] || `${base}-USD`,
      coingecko: COINGECKO_IDS[sym] || null,
      assetClass: 'crypto', note: `OKX ${base}/${q}`,
    };
  }
  const ticker = YAHOO_MAP[sym] || sym;
  return { symbol: sym, provider: 'yahoo', ticker, assetClass, note: `Yahoo ${ticker}` };
}

/* ------------------------------------------------------------------ cache */

const cache = new Map(); // key -> { at, candles, meta }
const CACHE_MAX = 300;

function cacheGet(key, ttlSec) {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > ttlSec * 1000) { cache.delete(key); return null; }
  return hit;
}
function cacheSet(key, candles, meta) {
  if (cache.size > CACHE_MAX) cache.delete(cache.keys().next().value);
  cache.set(key, { at: Date.now(), candles, meta });
}
function clearCache() { cache.clear(); }

/* ------------------------------------------------------------------ fetch */

async function fetchJson(url, { timeout = 12000, headers = {} } = {}) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeout);
  try {
    const res = await fetch(url, {
      signal: ctl.signal,
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; TradeJournalPro/2.0)', Accept: 'application/json', ...headers },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

const n2 = (v) => (Number.isFinite(v) ? v : null);

/** Yahoo chart API -> bars. Tries both hosts (they fail independently). */
async function yahooCandles(ticker, interval, range) {
  const path = (host) => `https://${host}/v8/finance/chart/${encodeURIComponent(ticker)}?range=${range}&interval=${interval}&includePrePost=false`;
  let lastErr = null;
  for (const host of ['query2.finance.yahoo.com', 'query1.finance.yahoo.com']) {
    try {
      const j = await fetchJson(path(host), { timeout: 14000 });
      const r = j && j.chart && j.chart.result && j.chart.result[0];
      if (!r || !r.timestamp) throw new Error('no result');
      const q = (r.indicators && r.indicators.quote && r.indicators.quote[0]) || {};
      const out = [];
      for (let i = 0; i < r.timestamp.length; i++) {
        const o = n2(q.open && q.open[i]); const h = n2(q.high && q.high[i]);
        const l = n2(q.low && q.low[i]); const c = n2(q.close && q.close[i]);
        if (o === null || h === null || l === null || c === null) continue;
        out.push({ t: r.timestamp[i] * 1000, o, h, l, c, v: n2(q.volume && q.volume[i]) || 0 });
      }
      if (!out.length) throw new Error('no bars');
      return { candles: out, meta: { provider: 'yahoo', ticker, currency: r.meta && r.meta.currency, exchange: (r.meta && r.meta.exchangeName) || null, tz: (r.meta && r.meta.exchangeTimezoneName) || null } };
    } catch (e) { lastErr = e; }
  }
  throw new Error(`Yahoo ${ticker}: ${lastErr ? lastErr.message : 'unavailable'}`);
}

/** OKX public candles -> bars (newest first upstream, reversed here). */
async function okxCandles(instId, bar, limit = 300, { after = null } = {}) {
  const cursor = after ? `&after=${encodeURIComponent(after)}` : '';
  const url = `https://www.okx.com/api/v5/market/candles?instId=${encodeURIComponent(instId)}&bar=${bar}&limit=${Math.min(Math.max(limit, 20), 300)}${cursor}`;
  const j = await fetchJson(url, { timeout: 14000 });
  if (!j || j.code !== '0' || !Array.isArray(j.data)) throw new Error((j && j.msg) || 'OKX error');
  const out = j.data
    .map((row) => ({ t: Number(row[0]), o: Number(row[1]), h: Number(row[2]), l: Number(row[3]), c: Number(row[4]), v: Number(row[5]) }))
    .filter((b) => [b.t, b.o, b.h, b.l, b.c].every(Number.isFinite))
    .sort((a, b) => a.t - b.t);
  if (!out.length) throw new Error('OKX returned no bars');
  return { candles: out, meta: { provider: 'okx', ticker: instId } };
}

/** CoinGecko OHLC fallback (only 1d/4h style granularity for short ranges). */
async function coingeckoCandles(coinId, days = 30) {
  const url = `https://api.coingecko.com/api/v3/coins/${encodeURIComponent(coinId)}/ohlc?vs_currency=usd&days=${days}`;
  const arr = await fetchJson(url, { timeout: 15000 });
  if (!Array.isArray(arr) || !arr.length) throw new Error('CoinGecko returned no bars');
  const out = arr.map((r) => ({ t: r[0], o: r[1], h: r[2], l: r[3], c: r[4], v: 0 })).sort((a, b) => a.t - b.t);
  const step = out.length > 2 ? out[1].t - out[0].t : 4 * 3600e3;
  return { candles: out, meta: { provider: 'coingecko', ticker: coinId, barMs: step, note: `${Math.round(step / 3600e3)}h bars` } };
}

/* ------------------------------------------------------------------ aggregation */

/** Group bars into buckets of `factor` base bars (aligned to the UTC epoch). */
function aggregate(candles, factor) {
  if (!factor || factor <= 1) return candles;
  const out = [];
  for (let i = 0; i < candles.length; i += factor) {
    const slice = candles.slice(i, i + factor);
    if (!slice.length) continue;
    out.push({
      t: slice[0].t,
      o: slice[0].o,
      h: Math.max(...slice.map((b) => b.h)),
      l: Math.min(...slice.map((b) => b.l)),
      c: slice[slice.length - 1].c,
      v: slice.reduce((a, b) => a + (b.v || 0), 0),
      n: slice.length,
    });
  }
  return out;
}

/** Defensive clean-up so the engines never see a malformed bar. */
function sanitise(candles) {
  const out = [];
  for (const b of candles) {
    const o = Number(b.o), h = Number(b.h), l = Number(b.l), c = Number(b.c);
    if (![o, h, l, c].every(Number.isFinite) || o <= 0 || h <= 0 || l <= 0 || c <= 0) continue;
    out.push({ t: Number(b.t) || 0, o, h: Math.max(h, o, c), l: Math.min(l, o, c), c, v: Number(b.v) || 0, n: b.n });
  }
  return out;
}

/**
 * Fetch normalised candles.
 * @param {string} symbol  journal instrument symbol (XAUUSD, BTCUSDT, ES, AAPL…)
 * @param {string} tf      one of TF_KEYS
 * @param {{limit?:number, force?:boolean}} [opts] limit = bars to return (backtest wants ~1500)
 * @returns {Promise<{candles:Array, meta:object}>}
 */
async function getCandles(symbol, tf = DEFAULT_TF, opts = {}) {
  const info = tfInfo(tf);
  const res = resolveSymbol(symbol);
  const limit = Math.max(60, Math.min(Number(opts.limit) || 400, 3000));
  const key = `${res.symbol}:${info.key}:${limit}`;
  if (!opts.force) {
    const hit = cacheGet(key, info.ttl);
    if (hit) return { candles: hit.candles, meta: { ...hit.meta, cached: true } };
  }

  const errors = [];
  let got = null;

  // 1) Crypto -> OKX first (deep intraday history, always live)
  if (res.provider === 'okx') {
    try {
      const bars = Math.min(limit, 300);
      const first = await okxCandles(res.ticker, info.okx, bars);
      let candles = first.candles;
      // OKX caps each call at 300 bars: page backwards with the `after` cursor
      // (returns records EARLIER than the timestamp) until we have enough history.
      let guard = 0;
      while (candles.length < limit && guard < 10) {
        guard++;
        const oldest = candles[0].t;
        const paged = await okxCandles(res.ticker, info.okx, 300, { after: oldest }).catch(() => null);
        if (!paged) break;
        const older = paged.candles.filter((b) => b.t < oldest);
        if (!older.length) break;
        candles = older.concat(candles);
      }
      got = { candles, meta: { ...first.meta, note: `OKX ${res.ticker}` } };
    } catch (e) { errors.push('OKX: ' + e.message); }
  }

  // 2) Yahoo (everything, and crypto fallback)
  if (!got && info.yahoo) {
    try {
      got = await yahooCandles(res.ticker, info.yahoo, info.yahooRange);
    } catch (e) { errors.push('Yahoo: ' + e.message); }
  }
  if (!got && res.fallback) {
    try { got = await yahooCandles(res.fallback, info.yahoo || '1h', info.yahooRange || '1mo'); } catch (e) { errors.push('Yahoo fallback: ' + e.message); }
  }

  // 3) Timeframes Yahoo does not serve (3m, 4h…) -> aggregate a smaller one
  if (!got && info.yahooFrom) {
    try {
      const baseTf = tfInfo(info.yahooFrom);
      const base = await getCandles(res.symbol, info.yahooFrom, { limit: limit * (info.agg || 4) + 20, force: opts.force });
      got = { candles: aggregate(base.candles, info.agg || 4), meta: { ...base.meta, aggregated: `${info.agg}×${info.yahooFrom}` } };
    } catch (e) { errors.push('aggregate: ' + e.message); }
  }

  // 4) CoinGecko last resort for crypto
  if (!got && res.coingecko) {
    try {
      const days = info.key === '1w' || info.key === '1d' ? 365 : info.key === '4h' ? 90 : 30;
      got = await coingeckoCandles(res.coingecko, days);
      errors.push('fell back to CoinGecko (coarser bars)');
    } catch (e) { errors.push('CoinGecko: ' + e.message); }
  }

  if (!got) throw new Error(`No candles for ${res.symbol} ${info.key} (${errors.join('; ')})`);

  let candles = sanitise(got.candles);
  if (candles.length > limit) candles = candles.slice(-limit);
  const last = candles[candles.length - 1];
  const meta = {
    symbol: res.symbol, timeframe: info.key, timeframe_label: info.label, bars: candles.length,
    asset_class: res.assetClass, provider: got.meta.provider, ticker: got.meta.ticker,
    note: got.meta.note || res.note, currency: got.meta.currency || null,
    aggregation: got.meta.aggregated || null,
    first_bar: candles.length ? new Date(candles[0].t).toISOString() : null,
    last_bar: last ? new Date(last.t).toISOString() : null,
    last_price: last ? last.c : null,
    last_bar_closed: last ? (Date.now() - last.t) >= info.ms : false,
    warnings: errors,
    fetched_at: new Date().toISOString(),
    cached: false,
  };
  cacheSet(key, candles, meta);
  return { candles, meta };
}

module.exports = {
  TIMEFRAMES, TF_KEYS, CHART_TFS, tfInfo, resolveSymbol, getCandles, aggregate,
  clearCache, isCryptoSymbol, cryptoSplit, CRYPTO_YAHOO,
};
