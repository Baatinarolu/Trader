'use strict';
/** M93 read-only daily reported-process tally. Explicit APP rubric, not broker
 * truth, course numeric weights, legacy pattern-score rewrite or authority. */
const Process=require('./process-outcomes'),Execution=require('./execution-review'),Journal=require('./journaling');
const VERSION='daily-process-v1',MIN_SCORE=1,MIN_TIER=30,WEIGHTS=Object.freeze({high:12,medium:6,low:3});
const BASIS='Current owned UTC recorded ENTRY/rule-day actions, retained app admissions and current retrospective execution/core acknowledgements. Not broker, mental state, statistical edge or permission.';
const finite=n=>typeof n==='number'&&Number.isFinite(n),id=n=>Number.isSafeInteger(n)&&n>0,utc=ms=>new Date(ms).toISOString().slice(0,10);
function invalid(message,status=400){return Object.assign(new Error(message),{code:'behavior_day_invalid',status});}
function dateKey(s){try{return Process.dateKey(s);}catch{throw invalid('Select a valid UTC calendar date.');}}
const clock=(s,now)=>Process.clock(s,{now});
const tier=n=>n>=85?'Disciplined':n>=70?'Solid':n>=55?'Leaking':n>=40?'Undisciplined':'Critical';
function legacyWindow(trades){
 const C=require('./bots/correction'),rows=trades.filter(t=>t.status==='closed'&&t.exit!=null),mistakes=C.detectMistakes(rows),penalties=mistakes.reduce((n,m)=>n+(WEIGHTS[m.severity]||0),0),score=Math.max(0,Math.min(100,100-penalties));
 return {basis:'legacy_window_pattern_tally_not_daily_execution',behavior_score:score,behavior_grade:rows.length>=MIN_TIER?tier(score):'Insufficient sample',behavior_sample_sufficient:rows.length>=MIN_TIER,detector_minimum:5,tier_minimum:30,sample_trades:rows.length,mistakes,scope:'Existing window detector/weights/gates unchanged. Includes old outcome-based recurring pattern severities; raw100 below evidence floor is NOT a clean-day or execution certificate. Not a daily average or capital permission.'};
}
function evaluate({userId,accounts=[],trades=[],admissions=[],events=[],from=null,to=null,nowMs=Date.now()}={}){
 if(!id(userId))throw invalid('Owned daily review required.');if(from!=null)dateKey(from);if(to!=null)dateKey(to);if(from&&to&&from>to)throw invalid('UTC date range is reversed.');
 const owned=accounts.filter(a=>a.user_id===userId&&id(a.id)),ids=new Set(owned.map(a=>a.id)),all=trades.filter(t=>t.user_id===userId&&ids.has(t.account_id)),process=Process.evaluate({userId,accounts:owned,trades:[],admissions,events,nowMs}),days=new Map(),unassigned=new Map(),unassignedEvidence=new Map(),rowsByCycle=new Map();
 for(const a of owned){const q=Process.evaluate({userId,accounts:[a],trades:[],admissions,events,nowMs});unassignedEvidence.set(a.id,q.coverage.unassigned_evidence);}
 const get=(account,date)=>{const key=account+':'+date;if(!days.has(key))days.set(key,{account_id:account,date,current_trades:0,closed_trades:0,open_trades:0,reviewed_trades:0,admission_known:0,execution_known:0,core_known:0,unknown_trades:0,orphaned_actions:0,evidence_unavailable:0,unassigned_trades:0,chronology_unknown:0,ambiguous_cycles:0,known_penalty_points:0,score:null,tier:null,tier_basis:null,state:'unreviewed',incidents:[],context_counts:{},basis:BASIS,_rows:[],_incidents:new Map()});return days.get(key);};
 const add=(d,key,points,source,detail,tradeId,at)=>{if(!points)return;let incident=d._incidents.get(key);if(!incident){incident={action_key:key,trade_id:tradeId,at,points,sources:[],details:[]};d._incidents.set(key,incident);}incident.points=Math.max(incident.points,points);if(!incident.sources.includes(source))incident.sources.push(source);if(!incident.details.includes(detail))incident.details.push(detail);};
 for(const t of all){const at=clock(t.opened_at,nowMs);if(at===null){unassigned.set(t.account_id,(unassigned.get(t.account_id)||0)+1);continue;}const d=get(t.account_id,utc(at));d._rows.push(t);const key=t.account_id+':'+t.id+':'+t.opened_at;if(rowsByCycle.has(key)){d.ambiguous_cycles++;d.evidence_unavailable++;}rowsByCycle.set(key,t);}
 // Validate each actual admission with M91's same pure source contract; no DTO
 // permission or legacy/imported raw trade snapshot substitutes for a child fact.
 const captures=new Map();
 for(const a of admissions){if(a.user_id!==userId||!ids.has(a.account_id))continue;let date;try{date=dateKey(a.rule_date);}catch{continue;}const d=get(a.account_id,date),r=Process.evaluate({userId,accounts:owned,trades:[],admissions:[a],events:[],nowMs}),p=r.days.find(p=>p.account_id===a.account_id&&p.date===date);if(!p||p.evidence_unavailable||p.admitted_entries+p.exception_entries!==1){d.evidence_unavailable++;continue;}const key=a.account_id+':'+a.trade_id+':'+a.admitted_at;if(!captures.has(key))captures.set(key,[]);captures.get(key).push(a);if(!rowsByCycle.has(key))d.orphaned_actions++;}
 for(const p of process.days){const d=get(p.account_id,p.date);d.context_counts=p.context_counts;
  // M90-only older trade events can establish an actual exception/cycle, not a
  // fabricated ordinary admission. Admission+event duplicates already linked.
  for(const e of p.exceptions){const key=e.account_id+':'+e.trade_id+':'+e.at;if(!captures.has(key)&&e.sources.includes('event')){captures.set(key,[{event_only:true}]);if(!rowsByCycle.has(key))d.orphaned_actions++;}add(d,key,12,'guardrail_exception','Recorded one-action personal-stop exception; needs review, not verified broker misconduct.',e.trade_id,e.at);}
  d.evidence_unavailable=Math.max(d.evidence_unavailable,p.evidence_unavailable);
 }
 for(const d of days.values()){
  d.unassigned_trades=unassigned.get(d.account_id)||0;d.evidence_unavailable+=unassignedEvidence.get(d.account_id)||0;
  for(const t of d._rows){d.current_trades++;const key=t.account_id+':'+t.id+':'+t.opened_at,entryKnown=captures.get(key)?.length===1;if((captures.get(key)?.length||0)>1){d.ambiguous_cycles++;d.evidence_unavailable++;}if(entryKnown)d.admission_known++;
   const x=Execution.review(t,{nowMs}),j=Journal.info(t,nowMs),close=clock(t.closed_at,nowMs),ack=Process.clock(t.journal_reviewed_at,{canonical:true,now:nowMs}),entry=clock(t.opened_at,nowMs),chronologyKnown=t.status==='closed'&&close!==null&&entry!==null&&close>=entry,coreKnown=j.complete&&chronologyKnown&&ack!==null&&ack>=close,execKnown=x.state==='reviewed'&&chronologyKnown;
   if(t.status==='closed'&&!chronologyKnown)d.chronology_unknown++;
   if(t.status==='closed')d.closed_trades++;else d.open_trades++;if(execKnown)d.execution_known++;if(coreKnown)d.core_known++;
   const a=x.evidence?.adherence,stop=x.evidence?.stop_honoured;if(a!==null&&a!==undefined&&a<5)add(d,key,a<=2?12:a===3?6:3,'execution_review',`Current explicit adherence ${a}/5; APP tally weight, not P&L.`,t.id,t.opened_at);if(stop===false)add(d,key,12,'execution_review','Current explicit stop-not-honoured self-report.',t.id,t.opened_at);
   if(coreKnown&&t.mistakes_none===0)add(d,key,6,'core_review','Current explicitly declared mistake: '+t.mistakes,t.id,t.opened_at);
   if(t.status==='closed'&&entryKnown&&execKnown&&coreKnown)d.reviewed_trades++;else d.unknown_trades++;
  }
  d.incidents=[...d._incidents.values()];d.known_penalty_points=d.incidents.reduce((n,i)=>n+i.points,0);const complete=d.current_trades>0&&d.closed_trades===d.current_trades&&d.reviewed_trades===d.current_trades&&d.orphaned_actions===0&&d.evidence_unavailable===0&&d.unassigned_trades===0;
  if(complete&&d.closed_trades>=MIN_SCORE){d.state='scored';d.score=Math.max(0,100-d.known_penalty_points);if(d.closed_trades>=MIN_TIER){d.tier=tier(d.score);d.tier_basis='app_daily_report_tally_not_edge';}}
  else d.state=!d.current_trades&&!d.orphaned_actions?'observations_only':complete?'insufficient_daily_sample':'incomplete_evidence';delete d._rows;delete d._incidents;
 }
 const list=[...days.values()].filter(d=>(!from||d.date>=from)&&(!to||d.date<=to)).sort((a,b)=>b.date.localeCompare(a.date)||a.account_id-b.account_id),coverage={account_days:list.length,scored_days:list.filter(d=>d.score!==null).length,unscored_days:list.filter(d=>d.score===null).length,known_incidents:list.reduce((n,d)=>n+d.incidents.length,0),unassigned_trades:[...unassigned.values()].reduce((a,b)=>a+b,0),unassigned_evidence:[...unassignedEvidence.values()].reduce((a,b)=>a+b,0)},selected=all.filter(t=>{const at=clock(t.opened_at,nowMs);return at!==null&&(!from||utc(at)>=from)&&(!to||utc(at)<=to);});
 return {state:'available',timezone:'UTC',date_basis:'current_recorded_entry_and_original_rule_day',account_ids:[...ids],from,to,rubric_version:VERSION,minimum_closed_for_score:MIN_SCORE,minimum_for_tier:MIN_TIER,app_weights:WEIGHTS,days:list,trend:list.map(d=>({account_id:d.account_id,date:d.date,score:d.score,state:d.state})),coverage,window_pattern:legacyWindow(selected),broker_verified:false,basis:BASIS,scope:'Daily reported-process APP index:100 minus per-action MAX12/6/3, complete current admission/execution/core coverage and at least1 closed record. Missing evidence NULL, not clean100/zero. Tier below30 withheld. Not window-score replacement, M106 state gate, actual psychology/broker proof or permission/sizing/strategy/grade/core completion.'};
}


function unavailable(){return {state:'unavailable',days:[],trend:[],coverage:null,window_pattern:null,rubric_version:VERSION,timezone:'UTC',broker_verified:false,basis:BASIS,scope:'Daily evidence unavailable—not0/clean/complete. Existing financial/window/execution fields unchanged.'};}
async function inspect(userId,{accountId=null,from=null,to=null,store=null}={}){
 if(from!=null)dateKey(from);if(to!=null)dateKey(to);if(from&&to&&from>to)throw invalid('UTC date range is reversed.');if(accountId!=null&&(!['string','number'].includes(typeof accountId)||typeof accountId==='string'&&!/^[1-9]\d*$/.test(accountId)||!id(Number(accountId))))throw invalid('Account not found.',404);
 const {db}=require('./db'),read=async store=>{const accounts=await store.prepare('SELECT * FROM accounts WHERE user_id=?'+(accountId==null?'':' AND id=?')).all(...(accountId==null?[userId]:[userId,Number(accountId)]));if(accountId!=null&&!accounts.length)throw invalid('Account not found.',404);const trades=await store.prepare('SELECT * FROM trades WHERE user_id=? ORDER BY opened_at,id').all(userId),admissions=await store.prepare('SELECT * FROM guardrail_entry_admissions WHERE user_id=? ORDER BY id').all(userId),events=await store.prepare('SELECT * FROM guardrail_events WHERE user_id=? ORDER BY id').all(userId);return evaluate({userId,accounts,trades,admissions,events,from,to,nowMs:Date.now()});};return store?read(store):db.tx(async tx=>read(db.transactionStore(tx)));
}
async function optional(userId,options){try{return await inspect(userId,options);}catch{return unavailable();}}
module.exports={VERSION,MIN_SCORE,MIN_TIER,WEIGHTS,BASIS,invalid,dateKey,evaluate,legacyWindow,inspect,optional,unavailable};
