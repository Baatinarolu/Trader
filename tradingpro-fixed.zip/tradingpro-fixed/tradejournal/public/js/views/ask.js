/* views/ask.js — M109 the advisory channel: ask the journal what it already knows.
 * Deterministic, read-only, no model, no key, no network, no prediction, no permission.
 * Refusals are rendered as the answers they are, and nothing here may become an entry
 * decision: every line carries the surface it came from. */
(function (global) {
  'use strict';
  const Views = global.Views = global.Views || {}, U = global.U;
  let serial = 0;
  const ctx = () => ({ user: global.Store.user?.id, token: global.API.getToken() });
  const same = (c) => c.user === global.Store.user?.id && c.token === global.API.getToken();
  const KIND_LABEL = { fact: 'Fact', record: 'Record', unavailable: 'Unavailable', note: 'Note' };

  const A = Views.ask = {
    ctx, same,
    /** One answer line: the text is a text node and the source travels with it. */
    lineNode(entry) {
      const node = U.h('div', { class: 'ask-line', dataset: { askKind: entry.kind || 'note' } });
      node.appendChild(U.h('p', { class: 'small', dataset: { askText: 'true' }, text: entry.text }));
      node.appendChild(U.h('p', { class: 'tiny muted', dataset: { askSource: 'true' }, text: `${KIND_LABEL[entry.kind] || 'Note'} · source: ${entry.source}` }));
      return node;
    },
    /** A refusal or an honest non-answer: same renderer, plus the reason and its citation. */
    answerNode(out) {
      const node = U.h('div', { dataset: { askAnswer: 'true' } });
      if (out.topic && out.topic_label) node.appendChild(U.h('p', { class: 'tiny muted', text: `Topic: ${out.topic_label} (${out.topic})` }));
      for (const entry of out.answer || []) node.appendChild(A.lineNode(entry));
      if (out.refused && out.refusal) {
        node.appendChild(U.h('p', { class: 'sticky-note warn', dataset: { askRefusal: out.refusal.code }, text: `Refused — ${out.refusal.code}. The channel can answer: ${out.refusal.can_answer}.` }));
        for (const cite of out.refusal.cites || []) node.appendChild(U.h('p', { class: 'tiny muted', text: `Why (saved episode words): “${cite}”` }));
        if (out.refusal.intention_cues && out.refusal.intention_cues.money_target_sentences) node.appendChild(U.h('p', { class: 'tiny muted', text: 'Matched the same amount-plus-outcome pairing the M107 intention classifier refuses; nothing was stored.' }));
      }
      if (!out.refused && out.answered === false && out.reason) {
        node.appendChild(U.h('p', { class: 'sticky-note warn', dataset: { askUnknown: out.reason.code }, text: `Not answered — ${out.reason.code}. ${out.reason.because}` }));
        node.appendChild(U.h('p', { class: 'tiny muted', text: `Surfaces this channel owns: ${(out.reason.topics || []).join(', ')}.` }));
      }
      return node;
    },
    /** One card asks into its OWN answer box: with two cards mounted (a re-render, a second
     * dashboard) an answer must never land in the other card’s surface. */
    boxOf(root) { return root && root.querySelector ? (root.matches && root.matches('[data-ask-answer]') ? root : root.querySelector('[data-ask-answer]')) : global.document.querySelector('[data-ask-answer]'); },
    async ask(question, root) {
      const context = ctx(), number = ++serial;
      const box = A.boxOf(root);
      if (box) { box.innerHTML = ''; box.appendChild(U.h('p', { class: 'tiny muted', text: 'Reading stored facts…' })); }
      try {
        const out = await global.API.post('/ask', { question });
        if (!same(context) || number !== serial) return;
        if (!box) return;
        box.innerHTML = '';
        box.appendChild(A.answerNode(out));
        return out;
      } catch (e) {
        if (same(context) && number === serial) {
          if (box) { box.innerHTML = ''; box.appendChild(U.h('p', { class: 'sticky-note warn', text: `Could not read: ${e.message}. Nothing was changed and nothing was inferred.` })); }
          else global.App.toast(e.message, 'err');
        }
      }
    },
    /** The dashboard card: what it is, what it refuses, and the surfaces it owns. */
    card(v) {
      const node = U.h('section', { class: 'card', style: 'margin-top:14px', dataset: { askCard: 'true' } }), context = ctx();
      node.appendChild(U.h('h3', { text: 'Ask the journal — deterministic, read-only, no AI' }));
      node.appendChild(U.h('p', { class: 'field-note', text: 'Saved Ep29 says the edge of AI is speed — closing the gap between confusion and clarity mid-session. This channel is not an AI and claims none of the perks: no model, no API key, no network call, and no new data. It answers from findings this app already computed and stored (the coach’s own insights, the guardrail/cap state the entry engine reads, and your own records), it never writes anything, and it refuses market predictions, trade permission, mental-state readings and rule changes.' }));
      if (!v || !v.topics) { node.appendChild(U.h('p', { class: 'sticky-note warn', text: 'The advisory channel is unavailable — nothing was read, nothing inferred, and nothing about entries changed.' })); return node; }
      const chips = U.h('div', { class: 'row', dataset: { askChips: 'true' } });
      for (const topic of v.topics) {
        chips.appendChild(U.h('button', { class: 'btn sm ghost', type: 'button', dataset: { askChip: topic.id }, text: topic.example, onclick: () => { if (!same(context)) return global.App.toast('Workspace/session changed; reopen your own briefing.', 'err'); A.ask(topic.example, node); } }));
      }
      node.appendChild(chips);
      const row = U.h('div', { class: 'row' });
      const input = U.h('input', { class: 'input', type: 'text', maxlength: '280', placeholder: 'Ask about what is stored — e.g. what are my risk limits today?', dataset: { askInput: 'true' } });
      const send = () => { if (!same(context)) return global.App.toast('Workspace/session changed; reopen your own briefing.', 'err'); return A.ask(input.value, node); };
      row.appendChild(input);
      row.appendChild(U.h('button', { class: 'btn sm primary', type: 'button', dataset: { askSend: 'true' }, text: 'Ask (read-only)', onclick: send }));
      node.appendChild(row);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });
      node.appendChild(U.h('div', { dataset: { askAnswer: 'true' } }));
      const limits = U.h('details'); limits.appendChild(U.h('summary', { text: 'What this channel will not do' }));
      for (const item of v.cannot_know || []) limits.appendChild(U.h('p', { class: 'tiny muted', text: '· ' + item }));
      limits.appendChild(U.h('p', { class: 'tiny muted', text: `Refusal codes: ${(v.refusal_codes || []).join(', ')} — a refusal is a successful answer carrying its reason, not an error.` }));
      node.appendChild(limits);
      node.appendChild(U.h('p', { class: 'tiny muted', dataset: { askMeta: 'true' }, text: 'Authority: none. Asking cannot permit, block, size, grade or change anything, and no trading surface reads this channel. It cannot raise a cap, change risk, disable a block or edit a rule — those change only where you explicitly change them.' }));
      node.appendChild(U.h('p', { class: 'tiny muted', text: v.basis || '' }));
      return node;
    },
  };
})(window);
