# TradeJournal Pro

## M110 — the news stand-down is two clocks, not one (2026-10-13)

Saved Ep 30 states **two** news stand-downs of different length: a **pre-release block** (*"you
don't open new positions during that window where the news is coming out, like 15 minutes before
and after news"*) and a **separate, longer post-release settle** (*"after the news came out, you
want to wait for the volatility to settle, maybe 30 minutes to 60 minutes"*). The engine had
**one** number applied symmetrically (`Math.abs(event − now) ≤ windowMin × 60000`), so the two
periods were forced to be equal — and a block value he sanctions (*"you can set it to 5 minutes,
10 minutes, 30 minutes, 60 minutes"*) silently collapsed the settle to the same number, **6–12×
shorter than the 30–60 minutes he requires**. His own UI separates them: a block **window** plus a
block **behaviour**.

**Two settings, two columns, one asymmetric test.** `news_block_before_min` (default **15**,
bounds 1–240) and `news_settle_after_min` (default **45**, **floor 30**, bounds 30–240) are separate
`accounts` columns with their own CHECKs, read through **`src/news-window.js`** — a leaf module
that requires nothing, reads no clock of its own, and answers identically when copied out of the
tree. `hit(eventMs, nowMs, plan)` is the only rule: a release that has **not printed** is judged by
the block, one that **has printed** by the settle, boundaries inclusive; `NaN`, `undefined` and
malformed pairs match **nothing** rather than everything. Because his requirement is a
**recommendation** and the settle floor is the only hard line, a block below 15 stores as set with
`news_block_before_below_recommended` and **never** shortens the settle, while a settle under 30 is
refused outright — **400 `news_settle_below_floor`** on create and on update.

**A single number is refused, not split.** `window_min`, `windowMin`, `newsWindowMin`,
`news_window_min` and the old `?window=` are all **400 `news_window_split_required`**, checked
*before* the split fields so one cannot ride along beside a valid pair. `plan()` clamps on read and
reports `source`/`clamped` per side, so an account stored outside the bounds is corrected and
**told**, not silently changed. The blackout sentence interpolates the account's own two numbers
and names the side that caught the release (`in X min` / `printed X min ago`), the top-level
single `window_min` is **gone rather than deprecated**, and `setup.js`'s fallback states the two
windows in his direction instead of the hardcoded, one-sided *"next 60 minutes"* — the surviving
half of **M62**, closed here. This milestone **split a window; it did not retune a grade**: the
news check keeps its weight and label, the state gate's own 60-minute `window_minutes` is
untouched, and the risk guardrail still clamps beside it.

**Measurement.** **M110 258/0 across 9 probes** (module 41, API 40, engine 25, consumers 22,
freshness 17, hardening 40, portable 17, the actual **c09574e M109 release as the upgrade parent**
33/0 — two additive columns, every inherited fact byte-identical, re-opening a no-op — and
real-DOM settings-dialog 23/0). **M109 166/2, M108 257/2, M107 230/2, M106 316/2, M105 140/2**
re-run on this tree, where every extra failure is the same **declared negative**: a frozen
migration probe asserting its milestone added *only* its own schema objects, plus an
inherited-facts comparison that covers `accounts`, now legitimately carrying M110's two columns.
The pre-hardening runtime — the loose module and route where one number still sets both sides — was
measured by the *unchanged* probes at **31/9** and **39/1**, and is 40/0 and 40/0 after the
hardening stage. The **calendar is fed through the app's own fetch path and parser** in every
probe, and no market provider is reachable from this sandbox, so the engine probe drives declared
synthetic structure and **no live-market or provider claim is made**. **M111 is not solved here**
and is stated as such: a calendar that cannot be fetched still arrives as a quiet week (null
blackout, no `unavailable` flag). Ledger **132 = 105 done / 2 partial / 25 TODO**. Report
`analysis/M110-NEWS-WINDOW.md` in the ZIP. Next **M111** (the fail-open) and **M112**; no 70 %
win-rate, causal/predictive edge, broker/provider/human/mental-state/pixel/production claim, and
no predictor of any kind.

## M109 — the advisory channel: ask the journal, deterministically (2026-10-13)

Saved Ep 29 argues for AI by **speed of feedback** — closing the gap between *confusion and
clarity, emotion and logic, mistake and lesson, impulse and discipline* mid-session. This
delivers the part of that which a self-hosted journal can own honestly: an **Ask the journal**
card on the Dashboard that answers questions from findings the app has **already computed and
stored**. It is emphatically **not an AI**: there is **no model, no API key and no network
call** — every payload says so (`llm:false`, `model:null`, `api_key_required:false`,
`network:false`) — and the same stored state with the same question returns the same bytes.

**Seven surfaces, read-only.** *What the gate currently reads*, *my limits and today's risk
facts*, *what the app sees in my logged trades* (the coach's own insights, narrated not
recomputed), *my numbers as history not a forecast*, *the records I stored today* (M106 gate
answers, M107 intention, M108 practice, the routine cycle), *the rules and checklist I
recorded*, and *news/calendar state* — which answers **unknown**, because the channel performs
no fetch and will not translate "I could not look" into "no high-impact news". Every answer
line carries its **kind** (`fact`/`record`/`unavailable`/`note`) and the **surface it came
from**; a missing, malformed or unreadable input is reported `unavailable` with the reason and
is never rounded to zero, repaired or invented.

**Six refusals, as answers.** Market direction, odds and predictions
(`ask_refused_prediction`); "should I buy/sell/enter", signals and picks
(`ask_refused_permission`); "am I calm/tilted/ready" readings (`ask_refused_mental_state`) —
the app stores *your* answers, and quoting them back is not a measurement of you; questions
about another person's account (`ask_refused_other_person`); "raise my cap / disable the news
block" (`ask_refused_override`); and an amount asked for as an outcome
(`ask_refused_outcome_target`, the same amount-plus-outcome pairing M107's classifier refuses).
A refusal is a **200 success** carrying its reason, the episode's own words and what the
channel *can* answer instead. A question that lands on no owned surface is an honest
non-answer listing the surfaces it does own — never an invented reply.

**No authority, and nothing written.** The module exports no write path, builds no SQL by
concatenation, and is required in exactly one place — the route that exposes it. A full
battery of asks leaves **every table byte-identical**, including *not* creating the lazy
practice-timer row M108's own read creates. Asking cannot permit, block, size, grade or change
anything; the entry engine remains the only authority, and **no engine, bot, guardrail,
routine, gate, intention or practice module requires this channel**. Questions are bounded to
280 characters of plain single-line text (markup and control characters refused), and extras
in the request body cannot scope, re-date or re-timezone an answer.

**Measurement.** **M109 168/0 across 9 probes** (read-only/byte-identical proofs in `pure` and
`api`; consumers18/0, freshness11/0, hardening17/0, portable16/0, real-DOM ui27/0, and the
actual143-parent migration 15/0 proving **zero schema added** and every inherited fact
byte-identical). Every prior cohort re-run unchanged — M108 259/0, M107 231/1, M106 317/1,
M105 141/1, one declared milestone-only schema negative each; the RAW596/156, DECLARED824/4 and
live-provider70/1 arms are inherited from the M108 record and **not** re-run.
The pre-hardening control tree — the module reading practice through M108's own reader,
counting a row it cannot read back, and swallowing an unparseable stop payload — was measured
by the *unchanged* probes at 14/3 and 28/3 before the fix and is 17/0 and 31/0 after it. Smoke
21/21 views, 0 style failures, 0 console errors on both the delivered tree and its parent.
Ledger **132 = 103 done / 2 partial / 27 TODO**. Report
`analysis/M109-ADVISORY-CHANNEL.md` in the ZIP. Next M111/M112 (M110 was delivered separately); no 70 % win-rate,
causal/predictive edge, broker/provider/mental-state/human/pixel/production claim, and no
predictor of any kind.

## M108 — the regulation layer: a personal practice log (2026-10-13)

The other half of Ep 28's *sanctuary* — the meditation timer, the interval bells, the
ambient-sound choice, the post-session note, the progress view and the mental toolkit —
now ships as an **independent practice log**. The **Practice** card sits on the Dashboard
and on the owned day review, with two doors: *Open the practice timer* and *Progress
(records, not results)*. It is deliberately narrow about what it can prove:
**the only thing measured is elapsed server running time** — a paused gap does not count —
and nothing in the app claims that a meditation happened, that anyone calmed down, or that
any physiological, emotional or performance effect followed.

**Timer.** The episode's own presets (5/10/15/30/60 minutes) or your own h/m/s length
(1 minute – 2 hours), with start, pause, resume, complete and cancel. Interval bells are
**elapsed-time markers** (none/1/2/5/10 minutes): they are listed as markers reached, and
a bell is sounded with a short tone generated locally in your browser — no audio file
ships and nothing is fetched. The **ambience** choice (none/rain/ocean/forest/fireplace/white
noise) is recorded as *your own declaration* and every payload says so
(`ambience_played_by_this_app:false`) — this app plays no ambient audio and streams
nothing. A session left open for more than 24 hours cannot be completed as one session;
cancel it instead. Every write carries the displayed revision, so a stale tab 409s with
nothing written, and a reload button is always there.

**Records, not results.** *Complete and record* writes an immutable receipt with the
measured running time, the markers reached, the note you wrote (up to 2000 characters) and
the optional one-line intention. The progress view counts **records**: sessions and
measured seconds, by day or by period, plus "consecutive days with a recorded session" —
never a streak to protect, a target, a score or a percentage
(`counts_are_records_only:true`, `target:null`, `score:null`). An empty day is not a
failure, stopping early is recorded exactly as it happened, and a stored receipt the app
cannot read back is reported `unavailable` and **never counted** as a session or as a
measured second.

**No authority, and never desk-scoped.** The practice log is personal: no `/practice`
route accepts an `account_id`, so a practice record cannot be attributed to an account or
a desk. Nothing here admits, refuses, sizes, scores or gates a trade, and nothing changes
risk, caps, routine, the core, grades or history — M64's mandatory 15-minute routine step,
M106's fresh in-session four questions and M107's daily intention keep their own meaning.
The optional intention line reuses M107's bounded classifier: free text stays stored as
written and labelled **unverified**, and an asserted money target is refused with the same
refusal code it gets there.

**Measurement.** **M108 259/0 across 9 probes**, actual141-parent additive/restart
migration 21/0; every prior cohort re-run unchanged (M107 231/1, M106 317/1 and M105 141/1
with one declared milestone-only schema negative each, changes152/1, opportunities144/1,
reviews159/1, behavior113/2, process106/2, screenshots223/3, emotions170/0,
confluences160/0, execution260/0, routine321/0, offline178/0, market325/0, RAW596/156,
DECLARED824/4). Ledger **132 = 102 done / 2 partial / 28 TODO**. Report
`analysis/M108-SANCTUARY-PRACTICE.md` in the ZIP. Next M109 (now separately delivered); no 70 % win-rate,
causal/predictive edge, broker/provider/mental-state/human/meditation/pixel/production
claim.

## M107 — one process intention for the day (2026-10-13)

**Dashboard**, the owned **day review** and **Settings** now carry the saved rule from
the course: *one clear rule for the day — one simple sentence, process-oriented,
behavioral, within your control.* You pick one of four saved examples (*Today I follow my
plan*, *Today I will take only A+ setups*, *Today I will journal every trade*, *Today I
will not revenge trade*) or write your own words. The saved example is the only thing the
app labels **process-oriented**; your own words are stored **exactly as written** and
explicitly **unverified**, with the cues the bounded, explainable classifier found
(sentence count, amounts, outcome/prediction/control wording, length) shown next to them.

The one thing refused is the episode's own anti-example: an **amount and an outcome
asserted in the same sentence** — *“Today I’m going to make $5,000 from the market”*, *“I
will make 5% today”* — is refused with a message naming the process alternative, and
**nothing is stored**. Everything else is recorded as written: *“have a green day”* is
stored and labelled as reading like an outcome, and *“I will not turn a $500 loss into a
revenge trade”* is stored with no refusal, because the app does not run sentiment
analysis and will not pretend to judge your words.

An intention is a **same-day commitment**, never permission: it does not admit, refuse or
size a trade, does not change risk, caps, routine, the core, grades or history, is never
scored or tallied for adherence, and is never proof that it was followed. Today only —
yesterday and tomorrow cannot be written or rewritten, no intention is carried over from
an earlier day, an identical repeat is a no-op, and a stale displayed revision 409s with
nothing written. Imported copies are `imported_unverified` archives keeping their original
day, clock and version as history; they are never the receiving account's recorded
intention and never displace it. M28's `journal_entries.tomorrow`, M64's morning
check-in, M89 emotion capture, M105's self-description and M106's fresh in-session gate
remain separate features.

**M107 232/0 across 9 probes**, actual139-parent additive/restart migration 18/0; every
prior M106 cohort re-run unchanged (317/1 with one declared M106-only schema negative,
M105 142/0-equivalent cohorts, changes152/1, opportunities144/1, reviews159/1, behavior113/2,
process106/2, screenshots223/3, emotions170/0, confluences160/0, execution260/0,
routine321/0, offline178/0, market325/0, RAW596/156, DECLARED824/4). Ledger
**132=101 done/3 partial/28 TODO**. Report `analysis/M107-DAILY-INTENTION.md` in the ZIP.
Next M108/M111/M112; no 70 %, causal/predictive edge, broker/provider/mental/human/
meditation/pixel/production claim.

## M106 — fresh in-session four-question state gate (2026-10-13)

**Dashboard** and the owned **day review** now carry the saved pre-entry check: *Am I
calm? Am I clear? Am I following the trade plan? Would I take this trade if I was
already up big today?* — and the saved rule that follows it, *“if the answer to any of
these questions is no, then you don’t trade yet.”* Answers are your own yes/no words
with a **server receipt**; the card, the editor and the readonly history never
preselect an answer, never accept free text, and never infer a state from your notes,
profit or adherence.

A recorded **no** refuses the app's own actionable surface the way the killzone veto
does: live entries and reopen on `POST/PUT /trades` answer 409 `state_gate_failed`,
saved signals/plans refuse with the same code, and `analyse`/`chart`/`scan`/Now refuse
with `NO TRADE` and a blocking guard. Freshness is the APP's own policy — same UTC day
and within the 60-minute window since the receipt — so yesterday's check is never
today's permission; an *adopted* account with no current check is equally refused. An
account that **never** answered is reported as `not_adopted` and is **not** blocked:
the desk does not invent a rule the trader never adopted. Imported copies are
`imported_unverified` archives with the original clock retained; they can never pass,
fail or block anyone. `record_only` history, closes, edits and imports stay legal, so
the check can never hold your journal hostage.

Answers are stored append-only and immutable; a stale displayed revision 409s with
nothing written, and a store outage 503s without claiming a receipt. `not_adopted`,
`passed`, `failed`, `unanswered`, `stale` and `unavailable` are distinct and visible —
including in the export/restore path and in Settings. This is a record of what you
said, not verified calmness, clarity, plan adherence, broker state, an edge, a
readiness/mental-state score or any authority over risk, admission, cap, routine, core
or grades. M89 emotion capture, M64's morning check-in and M107's daily intention stay
separate features; the gate is only the in-session check before a prospective entry.

**M106 318/0 across 10 probes**, actual137-parent additive/restart migration 18/0;
every prior M105 cohort re-run unchanged (142/0 with one declared M105-only schema
negative, changes152/1, opportunities144/1, reviews159/1, behavior113/2, process106/2,
screenshots223/3, emotions170/0, confluences160/0, execution260/0, routine321/0,
offline178/0, market325/0, RAW596/156, DECLARED824/4, pure70/1). Ledger
**132=100 done/3 partial/29 TODO**. Report `analysis/M106-STATE-GATE.md` in the ZIP.
Next M107. No 70%, causal/predictive edge, broker/provider/mental/human/meditation/
pixel/production claim.

## M105 — chosen self-description / separate quarterly theme (2026-10-13)

**Dashboard** and owned **day review** now show optional declared words: a persistent
self-description and a separate ~90-day calendar-quarter theme. Edit/explicitly
reset either; old versions/receipts and the theme's original identity reference
are retained. No “professional” default or copy from notes, profit, emotion, plan
or the saved next-period action focus. These are words you choose, not psychology,
self-worth, broker/action proof, trading readiness or a discipline score.

The daily card's plan-following tally uses **current acknowledged human execution
reviews** on UTC ENTRY day: followed/violated with known denominator, unreviewed,
partial known violations, open/imported/unassigned separately. Unknown share is
Unavailable, not clean100/0. Equal green/red process has the same counts; no P&L/
model/grade/identity score. A historical day can't borrow words received later.

New quarterly review snapshots retain the exact received self-description/theme
version/reference, distinct from M101's action focus. Later edits do not rewrite
its baseline;409 needs reload. The editor/readonly own history preserves original
words, escaped markup, and account/user/token/superseded/fault guards.503 never
claims saved or refunds a cap/routine/core/loss obligation. Themes use UTC APP
calendar quarters—roughly90days, not exactly90/broker hours. M106 fresh readiness
and M107 daily intention remain separate open findings.

Full JSON backup includes declaration history; restores get destination ownership,
new receiving receipts/imported-unverified INACTIVE archive status. Original words/
clock/reference remain declarations, not original mental state, human commitment
or plan-vote authority. Explicit later human adoption is a new declaration. Missing
store still permits finance backup with unavailable marker; malformed optional
history warns, actual import-store failure atomically rolls back that request.
Settings warnings/read-only imported/orphan histories visible, no auto-refresh
hiding omissions. Trade CSV does not carry standalone declared-word history.

APP limits500single-line chars,500portable records/8KBunverified reference +existing
20MBfile/25MBbody; no NLP/semantic uniqueness or automatic dedupe. Score/grade/risk/
entry/core/routine/geometry/stops/targets/RR/floor30/M103n>=5/B-C unchanged.
**M105142/0 across10**, actual135-parent migration13/0. Ledger
**132=99 done/3 partial/30TODO**. Native parent/current both204/2 on15syntheticfills/
0mismatches (same original>20floor assertions), negatives retained—not padded.
Report `analysis/M105-IDENTITY-QUARTER-THEME.md` in ZIP. NextM106. No70%, causal/
predictive edge, broker/provider/mental/human/meditation/pixel/production claim.

## M104 — named quarterly rule-change discipline (2026-10-12)

**Playbook** now shows UTC quarterly guidance across **all owned setups**. Editing a
setup reads fresh rules, previews each named delta, and asks you to review/continue
with the shown configuration. Saved advice/history remains visible. One change is
recommended, three maximum guidance; this is **advisory**, not a new technical,
capital, grade or trade veto. Existing direct API edits remain legal and return advice.

Counts are deterministic **APP edit units, not verified independent causal variables**:
paired rule-line additions/removals use max count, pure reorder1/scalar1, all eight
M102 rule fields inspected. Names/colour/pause excluded. Each saved edit/reversion
counts; another setup or deleting it cannot erase fresh tracked history. Unknown/
corrupt/missing/future/gapped history remains unavailable with a known minimum,
not a certified0/within-budget quarter. Deleted pre-install versions aren't recoverable.

Current setup/version/change fact save atomically, so a failed snapshot/history write
cannot leave half-applied rules or an unsnapshotted setup. Optional displayed revision
protects actual UI edits;409 retains draft/reload,503 never claims saved. An unversioned
current setup gets a pre-edit baseline, not invented original entry rules. Existing
trade attributions/financial numbers/grades/risk/weights/targets/RR stay unchanged.

New quarterly review snapshots retain their original rule-change guidance/baseline;
later edits don't rewrite the saved document. No review applies a plan. JSON backup
carries rule history; restore is readonly own **imported/unverified** declaration with
new receiving clock, not an actual strategy/action/quarter-budget replay. Archive
and Settings warnings visible; bad optional history warns while finance imports,
actual storage failure atomic, missing history still permits finance backup marker.

APP budgets500lines/5000chars,10000history records,500portable declarations/256KB
before-after pair; existing20MBfile/25MBbody limits, no silent clipping. One/three
course guidance doesn't prove causal attribution, an edge or70% wins. Floor30,
M103n>=5 and B/C tradeability unchanged. M105 identity/quarter theme remains next.

**M104153/0 across11**, actual133-parent migration14/0. Ledger
**132=98 done/3 partial/31TODO**. Older schema/raw/provider/mock negatives retained;
no broker/human/mental/meditation/pixel/production validation claim. Full report
`analysis/M104-QUARTERLY-RULE-CHANGE-DISCIPLINE.md` in delivery ZIP.

## M100 — saved opportunities are not automatically missed trades (2026-10-12)

**Bots → Signals → Review value/decision** records your explicit own-plan value
judgment, missed/not-taken/not-value/unknown choice, fear/hesitation/other reason
and note. Unreviewed never becomes a miss. Model pending/win/loss/no_fill/expired
is separate from actual entry or regret. APP-confirmed original method/personal
context is split from manual/legacy/unverified value reports; neither proves broker
execution or that you should override a stop. B/C tradeability unchanged.

Use **Record own trade from saved plan** to open the real financial form; recheck
market/own plan/routine/admission and enter your own size/emotion. Optional source
ID links only an exact saved plan and actual admitted entry. Material mismatch or
optional observation outage warns without undoing truthful finance. Explicit saved
journal links/retractions require owned same-account market/direction and preserve
history; one entry cycle cannot inflate multiple opportunity counts. Manual links
are self-report, not broker confirmation. Corrections/deletion don't erase original
association or refund caps/loss writing/routine; no automatic inferred misses.

Analytics and new periodic snapshots show explicit report/link counts with unknown,
unreviewed/prior/imported/legacy/unassigned coverage. Incomplete whole missed total
is **Unavailable**, not a zero-miss certificate. UTC opportunity record day, not
trade execution/close day. Original completed period baselines never recalculate.
Original first-target planned RR and already stored resolver MODEL R are shown
separately—**not lost profit, realised P&L, causal cost, prediction or sizing authority**.
No new resolver/candle fill, win-rate/risk/grade or70% promise.

JSON `opportunity_history` retains captures/decision/link declarations; trade CSV
does not carry standalone history. Restore forces new owned destination/receipt/
imported history, no native signal/live pointer/entry link/eligibility replay.
Original clocks remain unverified, including re-restore; bad clocks omitted with
warnings. Malformed optional evidence warns while finance remains legal; actual
import-store failure rolls back whole request. Missing history still allows finance
backup with explicit unavailable marker. Settings warnings stay visible. Readonly
orphan/import archives escaped, no automatic ownership transfer.

APP budgets (not course rules):notes<=2000,500portable records,50decision/link
entries per record,250KBrecord;20MBfile/25MBbody unchanged, no silent clipping.
Actual actor/token/account/serial/cache/409draft/reload/503guards; no grade/core/
financial/admission/technical-engine/floor/target/stop/RR changes. Independently
repaired inherited M99 sample-seed RESPONSE bug without changing seeding policy.

**Final145/0 across10**, actual131-parent migration13/0. Ledger **132=97 done/3 partial/32TODO**.
Older schema/mock/date/RAW/provider negatives retained. Next M104; M105/M106/M111/
M112 TODO, M30/M103/M108 partial. Report `analysis/M100-MISSED-VALUE-OPPORTUNITIES.md`
in delivery; no broker/human/mental/meditation/provider/pixel/production/edge validation.

## M99/M101 — periodic reviews and one committed focus (2026-10-12)

Open **Journal → Weekly / monthly / quarterly / annual reviews**. Select a cadence
and a date inside its UTC calendar period. Weeks start Monday—APP policy, not a
broker calendar. Each template asks different questions: weekly process feedback,
monthly lesson/barrier/pride, quarterly documented hypothesis/strategy baseline,
annual reassessment. Annual detailed prompts are **APP-guided**, not invented
course quotations. Existing daily notebook/core writing remains separate.

Start a draft, answer honestly (including unknown/not enough evidence), and choose
**one** focus. Completing answers freezes a server metrics/strategy-baseline receipt,
not the whole calendar period, profitable edge or permission to change a plan.
An in-progress period stays labelled early. Below30: don't tweak the system;30+
still doesn't prove causality/prediction. No weekly/monthly plan-apply or automatic
annual-goal/risk rewrite. M104's actual1–3-change enforcement remains open.

The exact adjacent prior completed focus/version/receipt is shown. Explicitly
choose **yes / no / unknown** for whether you acted on it, with your own reflection;
this is self-report, not execution proof. Prior amendments cannot move the old
answer's goalposts. Saved text/history/snapshot stay intact. Use deliberate
**amendment** to append a correction; stale409 retains input until reload,503
never claims saved. User/account/token/closed/superseded callbacks guarded.

Known closed-outcome denominators and unavailable net/R/drawdown/clock coverage
are explicit; open/other-account records excluded. Execution best/worst is process,
not biggest profit. Saved numbers don't silently recalculate after finance changes.
M100 missed setups/verified impulse counts remain unavailable, not guessed signals.
Quarterly saved owned strategy versions/current unversioned definitions preserve
what was actually available, not original entry rules or new strategy authority.

Full JSON backup carries `period_reviews`; trade CSV does **not** carry standalone
period artifacts. Restore appends destination-owned imported/unverified history,
new IDs/receiving clock, original declarations retained but no replayed completion/
acted/plan proof. Malformed optional history warns while finance remains legal;
actual storage failure rolls back that import. Missing history store still permits
financial backup with explicit omission marker. Settings warnings stay visible.
App budgets:4000chars/answer,300 single-line focus,1000amend reason,2000focus reflection,
10000account records/snapshot,500portable revisions/1MBdeclared snapshot each. Existing
20MBselected-file/25MBbody limits; no silent clipping or automatic dedupe.

**M99/M101 final160/0 across9**, actual129-parent migration/restart15/0. Ledger
**132=96 done/3 partial/33TODO**. Original schema-assumption negatives kept; full
report `analysis/M99-M101-PERIODIC-REVIEWS.md` in delivery. Next M100. M104/M105/
M106/M111/M112 open, M30/M103/M108 partial. No changed financial/risk/grade rules,
70% win-rate, broker/human/mental/meditation/pixel/production/market-edge promise.

## M93 — daily reported process, not the old window tally (2026-10-12)

**Day review, Journal index, Analytics, Coach and Bots → Corrections** now show
separate daily APP tallies and an account-separated trend. Process dates are UTC
**ENTRY/rule days**; finance/day best-worst remain their own close-day basis.
Current retrospective reviews can update an older entry day. Unknown points leave
trend gaps—not0 or a straight line through missing data.

A final raw tally requires each action's current captured entry cycle, explicit
execution acknowledgement and complete core/mistake-or-none review. Open, stale,
legacy/import-without-admission, prior/deleted/orphaned, ambiguous/undatable or
unavailable evidence remains **unscored**, with known incidents still shown.
No flags/no data is not clean100. One fully known action can be reviewed: **do not
force more trades to unlock a score or tier**. Daily tier below30 stays withheld.

APP points (not course quotations):100 minus per-action **MAX12/6/3**, not points
for every duplicate source: personal-stop trade exception12; explicit stop breach12;
current adherence1/2→12,3→6,4→3,5→0; current named core mistake6. Equal acknowledged
process gets the same raw tally on winning/losing trades. P&L/R/size/model/setup
quality/emotion/excursions/stop movement award no points; financial corrections
can honestly stale acknowledgements and require a fresh review.

The unchanged old gauge is labelled **Legacy window pattern tally**: its detector
still requires5 and its grade floor30 remains, with the same fields/weights. It can
still show raw100 below enough evidence; that is not the new day score or a clean
certificate. Numeric weights/minima are app display policy, not broker/mental-state,
statistical edge, trade quota, permission, sizing, grade change or core completion.

Read-only `GET /behavior-days` has owned account/date scope and explicit unavailable
on storage faults. No new schema, persisted score, score-bearing import or proof
backfill; current records never replay a child admission through client metadata.
See [docs/API.md](docs/API.md) / [docs/GUARDRAILS.md](docs/GUARDRAILS.md).

Measured **M93 115/0 across7**, actual-parent zero-schema/restart11/0. Ledger
**132=94 done/3 partial/35TODO**. M99 periodic review cadence is next; M103/M108
remain partial and M106/M111/M112 open. Old negative/raw/provider/mock/canvas results
kept separately—not an all-green production/broker/human/pixel/70% claim.

## M91 — positive money is not a clean-process certificate (2026-10-12)

**Day review, Journal index, Analytics and Coach** now separate financial outcomes
from recorded guardrail exceptions. A known profitable **whole owned UTC account-day**
with an actual saved trade exception under a personal stop gets a review annotation,
its original action/rules/reason/clock, and an invitation to identify a process fix.
**Financial wins, win rate, expectancy, scores and grades remain unchanged.**

A reached cap/profit ceiling, blocked entry, research exception or recording-time
observation is not proof of a traded violation. No captured history means unknown,
not compliant. Unknown/corrupt/undatable history or incomplete financial totals
remain explicit; missing amounts are not0. Filters to winning symbols/strategies
cannot make a losing whole account-day look profitable. Overnight entry-rule day
is not automatically the later profit close day. Reasons are historical; current
corrected journal totals can honestly change an association without rewriting them.

The Coach's **recorded flagged-day net** is associated current money, not a causal
“impact”/cost. The warning does not label every winner, prove psychological reward
or broker misconduct, punish profit, resize risk, grant entry, remove caps/routine,
or complete required core/post-loss writing. Review under the original selected
account; no automatic account switch. Existing finance/history imports remain
legal but cannot replay a server guardrail exception through DTOs.

Read-only `GET /process-outcomes` supports owned account/date scope, separate
account-days when all accounts selected, and explicit unavailable on read faults.
No new schema/columns or persisted flag, no new guard-history backup transport.
See [docs/API.md](docs/API.md) / [docs/GUARDRAILS.md](docs/GUARDRAILS.md).

Measured **M91 108/0 across6**, actual-parent migration/restart11/0; original M89
170/0, M88 reasons160/0, execution260/0, routine321/0. Historical M91 ledger **132=93 done/3 partial/36TODO** (current counts above).
M93 was next at that delivery (now separately applied); M106/M111/M112 remain open, M108 partial. Older
negative/provider/RAW/DECLARED/native/conditional-DOM results retained, not a claim
of production, broker, actual human/meditation, pixels or a70% win rate.

## M89 — timely APP emotional-state reports (2026-10-12)

After an admitted new/reopened trade is saved, answer **What emotion drove this
entry?**; after the actual close is saved, answer **How do you feel after getting
out?**. Start blank, name the state honestly or explicitly choose unknown; record
later/close does not infer none. The optional exit popup then leads to still-required
core/post-loss writing. Save truthful financial edits first. Review retained first
answers/context/history via **Emotion provenance** in the log, saved form, core or
day review; later journal text cannot replace that original answer/time.

**Five-minute APP policy, not a course quotation or broker-time proof.** The server
knows app-record/response clocks, not actual execution or your original mental
state. Entry answered after close stays late, even inside five minutes. Old text,
late/unknown/retrospective/imported/prior/unavailable evidence is not a timely
capture. Optional storage outage cannot undo a financial entry/close or complete
required writing. Captures never grant entry, reset caps/preparation or grade/size
risk; M106's fresh four-question gate remains open.

**Analytics → Segments** separates app-window entry self-reports, excluded-state
coverage and timing-unverified legacy text. Known-outcome denominators and unknown
net/R are explicit in the new cohort. Below30 is descriptive;30+ still does not
prove causality, predictive edge or sizing permission. No causal dollar “cost” or
70% win-rate promise. Existing engine/risk/targets/stops/RR and M103 n>=5 unchanged.

JSON `emotion_events` and CSV `emotion_events_json` retain first named/null reports
and declared old context/clocks. Restores get actual new owned IDs, imported source
and a new **receiving** clock, never verified old app/answer clocks/delay. Old
metadata/IDs remain unverified declarations. Invalid optional data warns without
vetoing truthful finance; actual import-store failure rolls back the request.
Missing capture storage still permits financial backup with explicit unavailable
markers. Warning-bearing CSV/Settings restores stay visible. App budgets:100-character
single-line state,50 history entries/trade,8KB original context/2048-character
primitive strings;20MB selected-file/25MB body limits unchanged. Repeated restore
can duplicate trades, not an upsert.

Measured M89 **170/0 across13** actual auth/SQL/DOM probes; parent migration14/0;
M88 reasons160/0, execution260/0, routine321/0. Historical M89 ledger **132=92 done/3 partial/37TODO** (current counts above).
M106/M111/M112 still open, M108 partial. Inherited/migration/provider/raw/native/DOM
negatives retained separately, not an all-green production/broker/human claim.
See `analysis/M89-TIMELY-EMOTION-CAPTURE.md` in the delivery ZIP.

## M88 — distinct entry confluences (2026-10-12)

Use **Entry reasons** in the trade log or review link in the saved financial form,
core-writing dialog or UTC day journal. On a new trade, type one market/setup
reason and **Add**; prior names appear in your own reusable dropdown. Commas stay
inside a label, not delimiters. Pick the actual **two to five** reasons, not10
invented ones. One honest reason is partial; **Unknown** differs from explicitly
**None**. Optional reasons never replace writing/emotion or grant entry/sizing.
Old trades and bots without an explicit human declaration remain unknown.

Save financial edits first; the separate saved-reasons editor uses the displayed
current revision. Unseen edits409 require deliberate reload; storage503 retains
the old field/time and finance. Only the new confluence columns are changed.
Human/imported source and server declaration/receiving time are shown: **not
verified original entry-time/broker/causal intent proof**, possibly retrospective.
M89 adds separate app-timed self-report provenance, not confluence timing proof. Labels are separate from tags, mistakes, entry
models/checklists, execution grades and HTF/MTF/LTF images; nothing backfilled.

**Analytics → Segments → Entry confluences** shows closed-trade descriptive
associations with overlapping labels, sample counts, known outcome denominators,
unknown net/R and human/imported counts. Do not add groups as independent trades.
Below30 closed trades per label: descriptive only;30+ still does not establish
prediction, causality, market edge, permission or risk advice. Course30 and M103's
deliberate n>=5 stay unchanged. No70% win-rate promise or model/exit retuning.

JSON backup carries trade reasons plus reusable prior-unused vocabulary; CSV
`entry_confluences` is a quoted **JSON-array cell**, not a comma-list of reasons.
Imports use new owned IDs/source/time, not backup entry-time/owner proof. Bad
optional evidence warns without vetoing financial truth; actual storage failure
rolls back the request. Warning-bearing restore stays visible. JSON unused-choice
restore budget5000 per request with an explicit warning if exceeded; CSV does not
carry unused choices. Repeat restore can duplicate trades. Existing20MB file
selection/25MB API body limits apply; split larger backups, never silent clipping.

## M87 — saved HTF / MTF / LTF chart references (2026-10-11)

Use **Visual evidence** in the trade log, saved-trade form, core-writing dialog
or day review. Save truthful finance first; then select three explicit human
timeframes and answer bias/structure/levels (HTF), location/liquidity (MTF) and
entry trigger/confirmation (LTF). Upload static PNG/JPEG/WebP or record a public
HTTPS link. No fixed4h/15m/5m defaults. Save one role at a time; save/reload clears
other unsaved selections. Clear-selection does not remove the saved image.

Legacy `screenshot_url` stays unassigned; never silently copied. A financial
correction retains older images and their saved context/time, with a prior-context
warning. PUT/remove requires the displayed current revision; stale screens409,
media-store failures503. Optional visuals do not complete mandatory writing,
score execution, reset preparation/loss/caps, resize risk or grant entry.

**Recording time is not original capture time.** Labels/references are not
verified chart pixels/timeframes or broker facts. Uploaded structure/bounds/CRC
checks are not full image decoding/legibility. External content is never fetched
by the server or automatically loaded in this editor; explicit viewing can
contact the remote site and content may have changed. Duplicate references and
equivalent/reused timeframes are flagged, not called independent chart views.
Recognisable credentialed/signed links and active/unsupported media are rejected.
App budgets:1.5MB decoded per upload,24MP,16,000px dimension; canonical frames
`m/h/d/w/M` (months use uppercase M). No market/broker/actual-capture verification.

JSON backup and CSV `screenshot_views_json`/`screenshot_url` carry owned optional
visual evidence. Restore creates new owned trade IDs, forces historical **imported,
unverified** source and new server receiving time; valid declared historical
time/context remain unverified, missing context remains unknown. Unsafe optional
media is omitted with explicit warnings while finance still imports. Real storage
failures roll back the request's financial/media mapping together. Old backups
remain compatible. Repeat restore duplicates historical trades; not an upsert.
Settings file selection limit20MB, backend JSON body25MB; never silently clip CSV.
For bigger backups split into smaller requests/account/date CSV slices. No
automatic large-backup batching or proof backfill.

Measured M87:226/0 across9 actual pure/auth/SQL/DOM probes; literal clocks and tiny
raster protocol fixtures, not real chart screenshots. Prior execution260/0 and
routine321/0; historical M87 ledger132=90done/3partial/39TODO (M88/M89 then open; now applied). Prepared
parent/current native Bots205/1 both (20 synthetic parity fills,0 mismatches;
inherited>20 sample floor), negatives kept rather than padded. Whole-app smoke
22/22 conditional DOM views,0 style/console,8 canvas limits, observed exit0; not
pixels. Source/core thresholds/geometry/RR/default risk unchanged. Full audit:
`analysis/M87-TIMEFRAME-SCREENSHOTS.md` in the delivery ZIP.

A **multi-asset trading journal, analytics engine, behavioural coach, SMC bot desk and TradingView-integrated
pre-trade assistant**. No subscription, no broker login, no sign-in wall — a Node server, one libSQL database
(a local file by default), and the whole thing deployable free to Vercel + Turso.

```
TradeJournal Pro  →  http://localhost:3000
Opens straight into a workspace (no sign-in).  Fresh start: Settings → About → Start a fresh workspace.
```

---

## Execution self-review (separate from entry setup grade)

After recording the actual close, use **Trade log → Execution** (also in saved
trade/core-writing forms). Explicitly review your own adherence1–5 and whether
you honoured the planned stop; unknown stays **Unreviewed**, never a made-up0.
P&L/R/planned RR/session/excursions add **no execution points**. The human
assessment is not broker verification or live emotional capture, does not
complete core writing/routine or change entry permission/risk. Save financial
edits first; a changed saved record requires reopening the current review.

Daily review shows **best/worst by reported execution**, retaining ties and
leaving unknowns unranked. Money-only extrema remain separately labelled; unknown
realised net is unavailable, not zero, and open floating data is excluded from
the realised day values. Existing numeric P&L statistics remain compatible.
The old “backfill grades” API is now a **read-only derived refresh**: `updated:0`,
with reviewed/unreviewed counts. It never overwrites `setup_grade`. Earlier stored
manual/model/auto-grade provenance cannot be reconstructed; values are retained
and explicitly separate from execution. See [API](docs/API.md) and
[guardrails](docs/GUARDRAILS.md). Entry models/checklist grades/risk factors,
price geometry and deliberate sample thresholds are unchanged.

## Personal-rule admission

New trade/reopen and prospective plan actions now recheck scoped personal rules
server-side. A known stop needs a recorded reason; an unavailable state cannot be
waived. Honest journal corrections/deletions remain possible but do not replenish
the durable admission count. See [the guardrails guide](docs/GUARDRAILS.md) for UTC
cap selection, optional realised profit ceilings, record-only/research modes,
fixed streak-independent base risk, optional manual session-time warnings, required
post-loss core writing/journal counters, limits and remaining scope. **No broker
is connected and an app admission is not a market-validated order.**

## What it does

| Area | What you get |
|---|---|
| **Journal** | 40+ fields per trade — thesis, execution notes, emotions, confidence, rule-adherence score, mistake tags, screenshots, MAE/MFE, planned R, **scale-out legs** (closes at the pct-weighted price). Works for FX, futures, stocks, ETFs, crypto, index CFDs and options. |
| **Analytics** | Expectancy ($ and R), win rate, profit factor, payoff, SQN, Sharpe, Sortino, Calmar, recovery factor, Kelly, max drawdown, streaks, R-distribution, MAE/MFE capture efficiency, time-of-day and weekday grids, hold-time buckets, 10+ segment tables. |
| **Coach** | 20+ deterministic behavioural tests on your own rows — losing setups, bad hours, revenge entries, post-loss trading, overtrading days, size creep, early exits, tight stops, cost of each mistake tag — each with the numbers, the dollar impact and one concrete action. |
| **Assistant** | Pre-session briefing with a clamped base risk unit and separate advisory drawdown/day-loss adjustment (never a streak multiplier), live economic calendar, headlines, quotes, watchlist, position-size calculator with true instrument specs, break-even win-rate maths, and a Monte Carlo drawdown / risk-of-ruin simulator. |
| **Daily habit** | Explicit three-line post-loss reflection, grey missing-journal markers and UTC core-journal counts (not inferred from profits/grades), optional manual elapsed-session warnings, calendar heatmap of P&L, day-review notebook (bias, mood, energy, plan, review, lessons), goals with live progress, pre-trade checklist builder. |
| **Data** | CSV import with automatic column detection, CSV export, full JSON backup & restore, multi-account (including prop-firm drawdown rules), instrument library. |
| **Options** | Black-Scholes calculator (price, delta/gamma/theta/vega, break-even, ITM/OTM), premium-based position sizing, and a plan that warns instead of printing a fake R:R when your target premium is below the entry. 7 option presets (100× multiplier). *IV is yours to type — there is no options feed.* |
| **Prop challenge** | Named challenge shapes (5 %/10 %, 6 %/6 %, instant…) applied to an account, then a live tracker over 4 checks — daily loss, max drawdown, profit target, consistency — with progress %. |
| **Exposure & heat** | Open positions grouped into correlation clusters (metals, USD, crypto, indices…) so long XAU + long XAG is counted as **one** bet, with total heat and warnings. |
| **Alerts & automation** | Webhook channels (Slack/Discord/Telegram/Zapier — https only) with a test button that reports the real HTTP status, a `trade_closed` event, and a scheduler (`/api/cron/tick`, `CRON_SECRET`-guarded, daily on Vercel's free plan) that resolves signals without the tab open. |
| **TradingView** | Official chart widgets on Market/Dashboard/trade form, correct symbol+interval deep links for all 57 instruments, and a **webhook that turns TradingView alerts into graded plans** (with an *agrees / conflicts* verdict against the bot's own read). |

---

## Interface rules (standing, enforced by the test suite)

The app is built to read like a trading terminal, not like an AI product. These are constraints, not
preferences, and `npm run test:ui` asserts four of them on every run:

* **No sign-in anything.** No login screen, no password field, no "create account", no auth-styled card.
  The browser is attached to a workspace automatically (`POST /api/auth/local`); the only card-shaped
  screen is a monospace *server unreachable* diagnostic with a Retry button.
* **No AI-style chrome.** No chat bubbles, no sparkle icons, no assistant mascot, no "powered by AI"
  badge, no emoji in the interface, no neon or purple gradient palette. Coaching arrives as findings
  with numbers, dates and a command to reproduce them — not as conversational text.
* **Icons are inline SVG drawn in code** (11 navigation icons, no icon font, no CDN). Text glyphs and
  emoji render differently on every platform and make a trading tool look like a toy, so they are not
  used: status reads as words — `ok` / `no`, `pass` / `fail`, `asc` / `desc` — with colour as a second
  signal, never as the only one.
* **Every number carries its provenance on screen** — the date, the sample and the script that produced
  it (`docs/MEASURED-RULES.md`, `docs/EDGE-REPORT.md`). Where a measurement says the model does not
  work, the interface says that too.

* **Terminal design language, not dashboard-template design.** Graphite neutrals (`#0b0d11` → `#1b1f27`),
  1px hairlines instead of drop shadows, 2–4px corners instead of 12–18px, dense 5px row padding, uppercase
  micro-labels on card headers and table heads, and **every number in monospace with tabular figures** so
  columns line up. Colour is reserved for state — P&L, pass/fail, risk — never for decoration. No gradients
  in the chrome, no glows, no purple anywhere in the palette.
* **Charts are real charts.** The desk chart is drawn in code (`public/js/chart.js`, canvas, no CDN, no
  iframe): candles with wicks, a volume pane, nice-number price ticks, clock-anchored time ticks, killzone
  shading, the dealing range with premium/discount, order blocks, fair value gaps, liquidity pools, sweep
  and structure markers, a crosshair with an OHLCV readout, wheel-zoom and drag-pan. Captions are placed by
  a collision-aware labeller, so levels stay readable instead of printing text over text. Every level drawn
  is a level the engine actually computed — nothing is decorative.
* **The build tells you what it is.** Every boot stamps a build id into the shell (`X-UI-Build` header,
  `data-build` attribute, and a `build …` line in the sidebar footer), and the shell + scripts + stylesheet
  are served `Cache-Control: no-store` with `?v=<build>` on every asset URL — so a restart can never leave
  a browser or a proxy showing the previous interface.

Current state, measured by the suite (2026-10-06): **11 inline SVG nav icons for 11 items, 0 emoji or
decorative glyph characters in rendered text, 0 in tooltips and labels, no auth UI present, build stamp
rendered in the sidebar, and — in a real Chromium — a 1328 × 560 desk chart whose canvas carries 39–41 %
ink across runs (43 572 of 106 240 sampled pixels on EURUSD 15m, 38.9 % in the final pass), a five-step method panel and three mini stack charts, 0 console errors from the app.**

---

## Quick start

```bash
cd tradejournal
npm install          # express + @libsql/client + technicalindicators (jsdom only for the test suite)
npm start            # → http://localhost:3000
```

The first run creates the schema, seeds the instrument library and a starter playbook, and **leaves your
workspace empty** — no trades, no journal, no goals, nothing you did not enter. No account, no password,
no wall. The dashboard then offers three explicit choices: log a trade, import a CSV, or load the
235-trade sample walkthrough (**Bots → Settings → Sample data**, clearly labelled and removable in one
click with `POST /api/demo/clear`).

Other commands:

```bash
npm test              # 121 API assertions against a running server (each run purges its own workspace afterwards)
npm run test:bots     # 205 bot-engine assertions (SMC, top-down gate, prediction, exit simulator, entry policies, corrections, webhook, refined plans)
npm run test:ui       # 21 view checks in jsdom + console-error report
npm run test:topdown  # 66 assertions on the video's method itself, on hand-built candles (incl. the step-5 gate and the plan's quality filters)
npm run test:chart    # 36 assertions that the chart draws candles, ranges, zones, pools and the plan box
npm run test:browser  # real Chromium: layout size, painted pixels, the method panel, overlay anchoring, wheel behaviour, screenshots (needs playwright-core)
npm run test:vercel   # 9 checks of the deployable entry point (handler + cold start), no deploy, no account needed
npm run test:all      # api + bots + ui + topdown + chart (~2.5 min)
npm run seed          # load the 235-trade sample workspace on purpose
npm run reset         # delete data/journal.db and rebuild (rebuilds empty)
```

Useful environment variables: `PORT` (default 3000), `HOST` (default 0.0.0.0),
`TRADEJOURNAL_DB` (path to the local SQLite file), `TURSO_DATABASE_URL` + `TURSO_AUTH_TOKEN`
(hosted libSQL — see **[docs/DEPLOY.md](docs/DEPLOY.md)**).

---

## Deploy it free

| | |
|---|---|
| **Local** | `npm install && npm start` — a SQLite file in `data/`, nothing else to do |
| **Vercel + Turso** | push to GitHub, import to Vercel, add `TURSO_DATABASE_URL` + `TURSO_AUTH_TOKEN`, deploy. `api/index.js` serves every `/api/*` request, `public/` is the front end, and the free Turso tier keeps the data. |

Full walk-through (Turso CLI, env vars, TradingView webhook, backups, troubleshooting):
**[docs/DEPLOY.md](docs/DEPLOY.md)**.

---

## Does it actually win? — the measured answer

Every claim in this app comes from a replay you can re-run yourself:

```bash
node scripts/edge-report.js --bars 2000 --step 6 --modes entry,leg,ote,mtf   # → docs/EDGE-REPORT.md
node scripts/rule-sweep.js                                                   # → docs/MEASURED-RULES.md
node scripts/mtf-report.js                                                   # → docs/MTF-REPORT.md
node scripts/stability-report.js --bars 4000 --step 6 --modes entry,leg      # → docs/STABILITY-REPORT.md
```

Headline reported by the run of **2026-10-06 11:57:05 UTC** (24 markets, 11 964 filled samples →
**11 411 unique setups**, 7 985 search / **3 426 untouched test**, **per-instrument costs** — spread +
slippage + commission per asset class, turned into R by each trade's own stop distance, mean 0.096R,
median 0.049R; stops closer than 0.25 × ATR are refused, 0 dropped in this pool):

* **≥ 70 % win rate and positive expectancy were not both available — measured, not asserted.** The win
  rate is a dial you turn with the target: 0.25R → **55.2 % net wins / −0.34R**; 0.35R → **55.8 % / −0.31R**
  (the peak); 1R → 45.8 % / −0.18R; 2.5R → 31.0 % / **−0.03R** (least bad); 3R → 27.1 % / −0.04R.
  **No target distance reached a 70 % net win rate.** Across **252 single/pair filters × 14 target
  distances** on the test window: **0 filters** reach 70 % net wins, and **0 of the 5 149 rule × exit
  combinations** cross 70 % *and* stay positive.
* **What does earn money** (positive in both halves): **`displacement leg` + stop ≥ 0.6 × ATR + first
  target ≥ 3R** → **+0.31R train / +0.56R test** (n 261 / 109) at a 35–42 % win rate — the tail pays for
  the misses (`node scripts/rule-sweep.js`, 2026-10-06 11:59 UTC, 7 028 unique setups). The most profitable single/pair filters on the untouched window: `rr>=2+ote` **+0.19R** at
  2.5R (39 % wins, n 120) and `range+rr>=2` +0.19R (n 632). The app now defaults to the measured shape
  (`full ★` in the Prediction view) and prints the reason under the chips.
* **The 70 % version exists and loses money.** Same sweep, 70/30 split: `ema50 agreement` + displacement
  leg, **stop ≥ 1 × ATR**, first target at **0.25R** wins **74.8 % train / 74.0 % test** (n 468 / 146) and
  returns **−0.084R / −0.116R per trade** — **0 %** of those trades bank ≥ +0.5R, because the target is
  smaller than the cost of getting in. Three configurations clear 70 % on both halves; none is profitable.
* **Second-chance re-entries lose money.** After a stop-out that never reached the first target, price
  re-tapped the level in **99.0 %** of cases and the re-entry won **14.2 %** of the time — **−0.35R per
  trade** pooled (net effect on *every* trade you take: −0.35R). The bots say that instead of teaching it.
* **Lower-timeframe confirmation (`?entry=mtf`)** has the highest win rate of any entry rule —
  **47.4 % pooled vs 35.1 % base** — and **still costs money**: on the 1 503 setups both rules filled,
  MTF is **+6.0 points of win rate and −0.268R of expectancy**, and the 321 setups it refuses but the base
  rule took averaged **+0.157R**. Market-by-market table + refusal counterfactual:
  [docs/MTF-REPORT.md](docs/MTF-REPORT.md).
* **Costs decide more than filters.** A 1h EURUSD entry with an 8-pip stop pays a median **0.216R** round
  trip; gold on 1h pays 0.025R. Every table in the app is net of those costs, per instrument.
* **Regime check** (4 000 bars, 8 markets, `stability-report.js`): only the flat-3R shape kept its sign in
  both halves (+0.11R → +0.05R); the video-plan-plus-gates combination **flipped +0.18R → −0.55R**
  (n 43/35), which is why the gate set is labelled regime-dependent rather than an edge.
  See [docs/STABILITY-REPORT.md](docs/STABILITY-REPORT.md).

Caveats that come with those numbers — one regime per market (~2 months of 1h candles), correlated
samples (the same zone is re-detected on consecutive bars), bar-based (not tick) MAE/MFE, class-default
costs rather than *your* broker's, and a pool that drifts a few setups between runs because the window
ends at run time. The date, the command and the sample live in each report; quote them together.

Read the whole thing, including the tables that fail: **[docs/EDGE-REPORT.md](docs/EDGE-REPORT.md)**.

---

## Architecture

```
server.js                 Express bootstrap, static hosting, crash guards, serverless handler
api/index.js              Vercel entry point (vercel.json rewrites /api/* here)
vercel.json               Static output + function limits for the free deploy
src/
  db.js                   libSQL data layer: schema, users/sessions, seeds, atomic batches
  routes/async-router.js  Express router that awaits handlers and forwards errors
  tradingview.js          TradingView symbol mapping, alert parsing, widget configs, deep links
  instruments.js          Instrument spec library + multi-asset P&L, R and position-size maths
  trades.js               Normalises client input into a fully-computed trade row
  performance.js          The analytics engine: KPIs, equity, drawdown, segments, Monte Carlo, Kelly
  coach.js                Behavioural rules + discipline score + pre-session briefing
  market.js               Economic calendar, RSS news, quotes, sentiment (cached, key-free)
  demo-data.js            Simulated trade history with deliberate behavioural leaks
  routes/api.js           REST API (auth, trades, analytics, coach, journal, market, import/export)
public/
  index.html, css/app.css
  js/util.js              Formatters + a small dependency-free SVG chart engine
  js/api.js, store.js     Fetch layer, app state, filters
  js/views/*.js           dashboard, trades, calendar, analytics, playbook, journal, coach, risk, market, settings
  js/app.js               Shell, hash router, modals, toasts, keyboard shortcuts
scripts/                  seed-demo.js, smoke-test.js
docs/                     user guide, metrics guide, API reference
```

**Design decisions worth knowing**

* **Everything normalises to R.** A 1.5-lot EURUSD trade and 2 ES contracts are only comparable if the journal knows the value of a 1.0 price move for each. `src/instruments.js` stores that per instrument, so expectancy, risk % and drawdown are truly multi-asset.
* **One source of truth for statistics.** The UI never computes a metric itself — `src/performance.js` does, so the dashboard, exports, coach and API can never disagree.
* **The coach is deterministic.** No LLM guessing: every insight is a statistical comparison with the sample size and dollar impact attached. You can audit the claim and reproduce it with a filter.
* **Local-first.** Market context is the only thing that talks to the internet, it is cached server-side, and every view degrades gracefully when you are offline.

---

## Keyboard shortcuts

| Key | Action |
|---|---|
| `n` | Log a new trade |
| `/` | Jump to the trade log search |
| `g` then `d/c/t/j/a/m/p/r/k/s` | Dashboard, Coach, Trades, Journal, Analytics, Market, Playbook, Risk, Calendar, Settings |
| `Esc` | Close the open modal |

---

## Security & privacy notes

* **No sign-in wall.** The app attaches to the workspace in your database; hosted, each browser gets a private
  workspace whose id lives in `localStorage`. Email/password endpoints still exist if you *want* them
  (`POST /api/auth/register`), but nothing in the UI requires them. Per-user rows are always scoped in SQL.
* Passwords (if used) are `scrypt` hashes with a per-user salt; sessions are random 256-bit tokens stored
  hashed, in an `HttpOnly; SameSite=Lax` cookie. Scripts can use `x-session: <token>` instead.
* The TradingView webhook is a **capability URL**: possession of the token equals permission to push an alert
  into your journal. It can only create alerts/signals, never read your journal, and it can be rotated in one
  click. Rotate it if you ever paste the URL somewhere public.
* The server binds to `0.0.0.0` so the in-browser preview works; if you only want it on your own machine, start
  with `HOST=127.0.0.1 npm start`.
* Your trades live in `data/journal.db` (or your Turso database). Copy that file — or the JSON backup — and you
  have everything.

---

## The bots

Sidebar → **Bots** opens five cooperating assistants built on one deterministic
Smart-Money-Concepts engine (the model taught in the *Market Mechanics Mentorship* playlist):

| Tab | What it does |
|---|---|
| **Market mechanics** | Top-down bias, structure (BOS/CHoCH/MSS), liquidity map, sweeps, order blocks, FVGs, breakers, premium/discount, CRT, killzones — scored 0–100 and drawn on a candlestick chart, with a plain-English read-aloud |
| **Prediction** | Replays the entry model over the market's own history (walk-forward, no hindsight, managed exits) and returns calibrated `P(win)`, expectancy, a per-grade table, an out-of-sample check and a buy/sell probability study |
| **Scan** | Ranks up to 24 markets by mechanics + setup quality — "where should I look right now?" |
| **Corrections** | Reads your journal, finds the mistakes costing you money **with numbers**, and derives personal guardrails (risk cap, daily trade cap, cooldown, loss-limit stop) from your own winning behaviour |
| **Signals** | Saves alerts and grades the bot's own record against live candles (win rate + expectancy by grade) |

Every plan carries entry, stop, target ladder, R:R per leg, position size in your
instrument's units, invalidation and a management rule (50 % at T1 → break-even → runner).
**Log this plan** pre-fills the trade form. The bots never place orders, and they say
**NO TRADE** far more often than not — by design.

**TradingView integration** — every panel carries a *TradingView ↗* link for the exact symbol and interval,
the Market view and Dashboard embed the official chart widgets, and **Settings → Integrations** hands you a
webhook URL: point a TradingView alert at it and each trigger is parsed, graded by the bot and stored with an
`agreement` verdict (does the bot read the same side of the market as your alert?). See
[docs/API.md](docs/API.md#tradingview) for the payloads.

Guides: [docs/BOTS.md](docs/BOTS.md) · [docs/PLAYLIST-CURRICULUM.md](docs/PLAYLIST-CURRICULUM.md)

## Pre-market routine (M14/M64/M94)

Use the **Routine** button in the header, or **Settings → Accounts → Edit rules**,
to select your own local trading-window start, an explicit IANA timezone and a
reset lead (1–180 minutes; Ep17 default60). No venue/broker hour is inferred.
An unfinished/setup-required routine keeps a banner across all pages. The default
steps are **calendar → own plan → chart/range, daily bias and alert report →
15-minute meditation/breathwork → four morning questions**. Meditation-first is
an explicit variant from the available bonus excerpt, not a claimed full bonus
workflow. The other known Ep17 steps remain. Policy and acknowledgments freeze
for the active cycle; edits take effect after its saved reset, including across
restart/midnight. DST uses the earlier repeated time and shifts a nonexistent
clock forward by the gap. This is not allowed-hour/broker-session enforcement.

The timer verifies only **server running time** between start/resume and pause/
completion, not actual meditation/focus. A running marker continues when the page
closes and survives restart; an explicit pause does not count. Human calendar and
chart/alert acknowledgments are not live provider clearance or order authority.
All FOUR morning answers must be explicit yes; no answers are retained and leave
the routine unfinished. They are not a fresh in-session/per-entry mental-state gate.

Known incomplete preparation uses the existing one-action typed-reason exception;
unknown/corrupt data cannot be waived. Truthful close/correction/history/import/
record-only writes remain legal. Completing a routine, editing its policy or
correcting/deleting a journal never refunds other caps/loss clocks or rewrites an
actual first-entry preparation snapshot. Late completion is shown as late.

**Journal** shows actual workflow completion, on-time preparation and separately
labelled nullable daily self-reports. Unrelated notebook edits preserve the human
flag/source/time. Workflow and self-report are not interchangeable permission.
The **routine vs daily realised P&L** table uses UTC close-day daily totals with
completed/not-completed/unknown groups and evidence basis; unknown P&L is not zero.
It is descriptive only, not causal proof, per-trade overnight attribution or an
instruction to resize/change strategy. No older completion is fabricated.

M108 is now **applied** as an independent practice log (presets/custom length, interval
bells, declared ambience, toolkit text, immutable receipts, records-only progress). This
routine step is unchanged and stays its own thing: a **mandatory 15-minute workflow timer
under the routine**, not the practice log, and neither of the two is evidence that a
meditation happened or that any mental state was reached. M89 app-timed self-report
provenance is separate from this routine; M107's intention and M106's fresh in-session
questions are separate from both. M111 fail-closed news and
M112 allowed hours remain open. See [docs/GUARDRAILS.md](docs/GUARDRAILS.md) and
[docs/API.md](docs/API.md#pre-market-routine).

## Docs

* [`docs/USER-GUIDE.md`](docs/USER-GUIDE.md) — how to actually use it, screen by screen, and the daily/weekly/monthly review routine.
* [`docs/METRICS-GUIDE.md`](docs/METRICS-GUIDE.md) — what every metric means, how it is calculated, typical benchmarks and the research behind it.
* [`docs/API.md`](docs/API.md) — the REST API if you want to build on top of it (or import from a script), including the TradingView webhook contract.
* [`docs/EDGE-REPORT.md`](docs/EDGE-REPORT.md) — the measured win-rate/exit frontier across 24 markets, with per-instrument costs: what the model does, what it can't do, and the exact command to reproduce it.
* [`docs/MEASURED-RULES.md`](docs/MEASURED-RULES.md) — the rule sweep: the highest win rate that survives out-of-sample, the configurations that actually earn, and why you cannot have both.
* [`docs/DEPLOY.md`](docs/DEPLOY.md) — free hosting on Vercel + Turso, alternative hosts, backups, troubleshooting.

### One answer per market, and it is dated

The Bots view now opens with a **now** strip: a single action (`WAIT / BUY / SELL / NO TRADE`), the
sentence behind it, the one level being watched, the next checkpoint on the clock, and the bar the
read came from with its age and how far price has moved since. The opposite side is named,
collapsed and **never priced** — a plan the higher timeframe does not permit is a scenario, not an
order. Any read can be re-created with **bar replay** (`?trim=N`), which rebuilds it from the
candles that existed then, so the rules cannot see the bars they are judged on. The desk chart adds
drawing tools (line, ray, price line, box, fib, measure, magnet), overlay studies (EMA 50/200,
VWAP) and size presets, and the drawings are stored in the database per market + timeframe. The
TradingView panel is now full width with its own toolbar, indicators and Full screen.
