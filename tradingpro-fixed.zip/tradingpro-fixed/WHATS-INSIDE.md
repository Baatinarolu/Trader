# What is in this archive

This is the **TradeJournal Pro** application from `tradingpro-main.zip` with **37 audit findings
fixed**, plus the complete audit that produced those fixes.

Built 2026-10-08 from branch `arena/0f969311-trader` at commit `5731d62`.

## Layout

```
tradejournal/        the application, patched (node_modules excluded - run `npm install`)
analysis/            the audit: 119 findings, probes, harness, measurements
ANALYSIS.md          the original whole-archive analysis
.gitignore           as committed
```

## Running it

```
cd tradejournal
npm install --no-audit --no-fund
node server.js            # http://localhost:3000
```

The database is created on first run; `data/` was deliberately excluded from this archive.

## The 11 source files that changed

(against the pristine `tradingpro-main.zip`; +788 / -93 lines total)

    src/bots/correction.js
    src/bots/index.js
    src/bots/predict.js
    src/bots/setup.js
    src/bots/smc.js
    src/bots/topdown.js
    src/coach.js
    src/db.js
    src/instruments.js
    src/routes/api.js
    src/trades.js

The exact diff is preserved at `analysis/patches/applied-so-far.patch`, so you can see every
change line by line, or apply it yourself to a fresh copy of the original archive:

```
unzip -q -o tradingpro-main.zip -d extracted
cd extracted/tradejournal && npm install --no-audit --no-fund
git apply ../../analysis/patches/applied-so-far.patch
```

## Reading the audit

Start with `analysis/PROGRESS.md` (generated summary), then `analysis/MISMATCHES.md` (the 119
findings, each with what does not match, what was changed, and its status), then
`analysis/harness/BASELINE.txt` (every measurement, **including the ones that came back negative**).

`analysis/EPISODE-AUDIT.md` holds the verbatim course quotes the findings are judged against.

## Verifying the fixes

```
cd tradejournal
for t in probe-batch0 probe-m58-grade-sizing probe-m21-strongweak probe-groupa-vetoes \
         probe-groupb-structure probe-m36-scale-in; do
  printf "%-26s " "$t"; node ../analysis/$t.js 2>&1 | grep -E "passed" | tail -1; done
npm run test:now
node scripts/api-test.js http://127.0.0.1:3000     # with the server running
```

Expected: 10/10, 20/20, 10/10, 18/18, 10/10, 17/17, 36/0, 121/0.

## Honest caveats

- All backtests run on **synthetic data** (`analysis/harness/synth.js`). No result here is evidence
  of a trading edge; they measure whether the engine's decisions are internally consistent.
- The best measured configuration is **break-even at 60 seeds** (`n=122, -0.0011R, PF 1.00`) and
  **negative at 120 seeds**. Nothing here is profitable.
- Four findings (M44, M48, M32, M43) were implemented and then measured to be **no better** as
  enforced gates. They are recorded as negative results rather than quietly shipped or dropped.
- 81 findings are still **todo**. This archive is a checkpoint, not a finished repair.
