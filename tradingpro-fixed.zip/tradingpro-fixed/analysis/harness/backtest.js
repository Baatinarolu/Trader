#!/usr/bin/env node
'use strict';
/**
 * INDEPENDENT WALK-FORWARD BACKTEST — measures the real setup engine, not a re-implementation.
 *
 * It calls the SAME code the server calls:
 *     SMC.analyse(candles, { tf, htfCandles })   →  src/bots/smc.js
 *     Setup.buildSetups(analysis, ctx)           →  src/bots/setup.js
 * and then simulates the entry / stop / target that the engine itself produced.
 *
 * ⚠ DATA IS SYNTHETIC (see synth.js). This measures whether the entry/stop/target
 * logic is internally consistent — profitable on data containing the structure the
 * method claims to exploit. It does NOT establish real-market edge.
 *
 * METHODOLOGY (stated so the numbers are auditable):
 *   · at each bar i, the engine sees ONLY candles[0..i] — no lookahead
 *   · a signal is acted on from bar i+1 onward
 *   · single target = targets[0] (T1). The code ships a 3-target ladder with a 50%
 *     partial (M51, unresolved); using T1 alone is the conservative single-target read
 *   · same-bar ambiguity (both stop and target inside one bar) resolves to the STOP —
 *     deliberately pessimistic
 *   · one position at a time; scanning resumes after the trade closes
 *   · R = (exit - entry) / (entry - stop), sign-corrected for side
 *   · results are broken out by grade, because the M95 decision (B and C remain
 *     tradeable) makes the per-grade expectancy the load-bearing number
 *
 * Usage:  node analysis/harness/backtest.js [--seeds 5] [--bars 900] [--window 300]
 */
const path = require('path');
const ROOT = path.join(__dirname, '..', '..', 'extracted', 'tradejournal');
const SMC = require(path.join(ROOT, 'src/bots/smc.js'));
const Setup = require(path.join(ROOT, 'src/bots/setup.js'));
const Synth = require('./synth.js');

const argv = process.argv.slice(2);
const arg = (k, d) => { const i = argv.indexOf('--' + k); return i >= 0 ? Number(argv[i + 1]) : d; };
const SEEDS = arg('seeds', 5);
const BARS = arg('bars', 900);
const WINDOW = arg('window', 300);
const WARMUP = 120;
// A trade gets a bounded life. Without this the walk runs to the end of the series and
// "price eventually reaches the target" is scored as an edge. Ep 27 gives the guidance:
// trades should last 30-50 minutes, 100 preferred — on 15m bars that is 2-7 bars, so 20
// bars (5 hours) is already generous.
const MAX_BARS = arg('maxbars', 20);
// After a trade closes, wait before re-entering. Otherwise one unmitigated zone is
// re-signalled on consecutive bars and a single idea is counted dozens of times.
const COOLDOWN = arg('cooldown', 12);
// Bars allowed for the limit order to fill before the idea is abandoned.
const FILL_WINDOW = arg('fillwindow', 12);
// The engine's own readiness flag. 'waiting' means "Chasing here breaks the model's edge"
// (setup.js:346) and 'approaching' means set an alert; only 'at-entry' says arm the order.
const ONLY_AT_ENTRY = argv.indexOf('--all-status') < 0;
// --at pins the killzone clock to ONE instant for every bar, reproducing the old wall-clock
// behaviour. Left unset, the clock advances with the candle. Comparing the two isolates how
// much of any result was an artefact of the hour the run happened to be executed at.
const argS = (k, d) => { const i = argv.indexOf('--' + k); return i >= 0 ? String(argv[i + 1]) : d; };
const AT = argS('at', null);
const AT_MS = AT ? Date.parse(AT) : null;
// M1: A/B the swing definition. 'local' (default) is the code's local-extremum tier; 'bos' is
// the course's "extreme that created the break of structure". Only for measurement.
// M1 + M22 are now the engine defaults; these flags let the OLD behaviour be restored.
const SWING = argS('swingmode', 'bos');
// M22: bound the minor tier by the range the major tier defines. Off by default.
const NESTED = argv.indexOf('--no-nested') < 0;
// M32: an order block is only valid if its creating leg left an imbalance (Ep 10).
const OB_FVG = argv.indexOf('--ob-fvg') >= 0;
// M44: any un-traded high or low can be a liquidity pool, not just the last four.
const ALL_SWINGS = argv.indexOf('--all-swings') >= 0;
// M47: let a retested flip zone be the point of interest, not just display data.
const USE_BREAKERS = argv.indexOf('--breakers') >= 0;
// M43: stand down when un-swept liquidity sits between entry and target, instead of banking a partial.
const STAND_DOWN_WALL = argv.indexOf('--stand-down-wall') >= 0;
// M51: restore the three-rung ladder with a 50% partial instead of one target.
const LADDER = argv.indexOf('--ladder') >= 0;
if (AT && Number.isNaN(AT_MS)) { console.error('bad --at: ' + AT); process.exit(2); }

/**
 * Two-phase simulation of a LIMIT order.
 *   phase 1  wait for price to actually reach the entry level (fill), up to FILL_WINDOW bars
 *   phase 2  from the fill bar, evaluate stop / target up to MAX_BARS bars
 * Assuming an instant fill was the single largest error in the first version of this
 * harness: the engine emits a limit price that can be far from market, and scoring an
 * unfilled order as a win produced the absurd +14R figure.
 */
function simulate(candles, from, lv, maxBars, fillWindow) {
  const buy = lv.side === 'buy';
  const entry = lv.entry, stop = lv.stop;
  const risk = buy ? entry - stop : stop - entry;
  if (!(risk > 0)) return null;
  const t1 = (lv.targets && lv.targets[0]) || null;
  if (!t1) return null;
  const target = t1.price;
  if (buy ? target <= entry : target >= entry) return null;

  // ---- phase 1: does the limit ever fill?
  let fill = -1;
  const fEnd = Math.min(candles.length - 1, from + fillWindow - 1);
  for (let i = from; i <= fEnd; i++) {
    const b = candles[i];
    // a buy limit fills when price trades down to it; a sell limit when price trades up to it
    if (buy ? b.l <= entry : b.h >= entry) { fill = i; break; }
    // price ran the other way: the idea is gone, not waiting
    if (buy ? b.h >= target : b.l <= target) return { r: 0, exit: null, bars: 0, outcome: 'missed' };
  }
  if (fill < 0) return { r: 0, exit: null, bars: 0, outcome: 'unfilled' };

  // ---- phase 2: manage the filled position
  const last_i = Math.min(candles.length - 1, fill + maxBars - 1);
  for (let i = fill; i <= last_i; i++) {
    const b = candles[i];
    const hitStop = buy ? b.l <= stop : b.h >= stop;
    const hitTgt = buy ? b.h >= target : b.l <= target;
    if (hitStop) return { r: -1, exit: stop, bars: i - from + 1, outcome: 'stop' };
    if (hitTgt) return { r: Math.abs(target - entry) / risk, exit: target, bars: i - from + 1, outcome: 'target' };
  }
  const last = candles[last_i];
  const r = buy ? (last.c - entry) / risk : (entry - last.c) / risk;
  return { r, exit: last.c, bars: last_i - from + 1, outcome: 'expired' };
}

function stats(trades) {
  if (!trades.length) return { n: 0, win: 0, exp: 0, pf: 0 };
  const wins = trades.filter((t) => t.r > 0);
  const gp = wins.reduce((s, t) => s + t.r, 0);
  const gl = Math.abs(trades.filter((t) => t.r < 0).reduce((s, t) => s + t.r, 0));
  return {
    n: trades.length,
    win: (wins.length / trades.length) * 100,
    exp: trades.reduce((s, t) => s + t.r, 0) / trades.length,
    pf: gl > 0 ? gp / gl : (gp > 0 ? Infinity : 0),
  };
}

const fmt = (s) => s.n === 0 ? 'n=0' :
  `n=${String(s.n).padStart(4)}  win=${s.win.toFixed(1).padStart(5)}%  exp=${(s.exp >= 0 ? '+' : '') + s.exp.toFixed(4)}R  PF=${s.pf === Infinity ? 'inf' : s.pf.toFixed(2)}`;

const all = [];
const t0 = Date.now();

for (let seed = 1; seed <= SEEDS; seed++) {
  const candles = Synth.series({ seed, bars: BARS });
  const htfAll = Synth.aggregate(candles, 4);
  let openUntil = -1;

  for (let i = WARMUP; i < candles.length - 5; i++) {
    if (i <= openUntil) continue;
    const win = candles.slice(Math.max(0, i - WINDOW), i + 1);
    const htf = htfAll.filter((b) => b.t <= candles[i].t).slice(-80);
    let analysis;
    // `now` is driven from the candle, not the wall clock. The engine multiplies the score by
    // (0.82 + 0.18 * sessions.quality) and quality runs 0.30 -> 1.00 across the day, so leaving
    // the clock free made every baseline time-of-day dependent (measured: identical candles
    // scored 30.57-33.13 depending on the hour). The series starts 2024-01-01T00:00Z on 15m
    // bars, so advancing `now` with the bar walks the run through every killzone -- which is
    // also what makes the killzone veto measurable instead of all-or-nothing per run.
    try { analysis = SMC.analyse(win, { tf: '15m', htfCandles: htf.length > 30 ? htf : null, now: AT_MS != null ? AT_MS : candles[i].t, swingMode: SWING, nested: NESTED, obRequiresFvg: OB_FVG, allSwings: ALL_SWINGS }); }
    catch (e) { continue; }
    if (!analysis || !analysis.ok) continue;

    let res;
    // Pass an account so the risk plan is built — M58 scales position size by grade, and
    // that only exists when balance/riskPct are present.
    try { res = Setup.buildSetups(analysis, { price: candles[i].c, balance: 10000, riskPct: 1, valuePerPoint: 100000, assetClass: 'forex', useBreakers: USE_BREAKERS, standDownOnWall: STAND_DOWN_WALL, ladderTargets: LADDER }); }
    catch (e) { continue; }

    const cands = (res && res.candidates) || [];
    const c = cands.find((x) => x.ok && x.levels && x.levels.entry > 0 && x.levels.stop > 0 &&
      (!ONLY_AT_ENTRY || x.levels.entry_status === 'at-entry'));
    if (!c) continue;

    const sim = simulate(candles, i + 1, c.levels, MAX_BARS, FILL_WINDOW);
    if (!sim) continue;
    openUntil = i + sim.bars + COOLDOWN;
    all.push({ seed, bar: i, side: c.levels.side, grade: c.grade, score: c.score,
      entry_status: c.levels.entry_status, rr_declared: (c.levels.targets[0] || {}).rr,
      // M58: the multiplier the engine applied, so dollar outcomes can be computed with and
      // without grade sizing from a single run.
      mult: (c.risk && c.risk.grade_risk_multiplier != null) ? c.risk.grade_risk_multiplier : 1,
      ...sim });
  }
}

const ms = Date.now() - t0;
const by = (f) => stats(all.filter(f));

console.log('\n' + '='.repeat(78));
console.log(' INDEPENDENT WALK-FORWARD BACKTEST  —  SYNTHETIC DATA');
console.log('=' .repeat(78));
console.log(` seeds=${SEEDS} bars=${BARS} window=${WINDOW} warmup=${WARMUP} maxBars=${MAX_BARS} fillWindow=${FILL_WINDOW} cooldown=${COOLDOWN}  gate=${ONLY_AT_ENTRY ? "entry_status==='at-entry'" : 'any status'}  ·  ${all.length} trades  ·  ${ms}ms`);
console.log(` engine: src/bots/smc.js analyse() + src/bots/setup.js buildSetups()  (unmodified paths)`);
console.log('\n ALL SIGNALS WHERE ok===true (the CURRENT gate, includes B and C)');
console.log('  ' + fmt(by(() => true)));
for (const g of ['A+', 'A', 'B', 'C']) {
  const s = by((t) => t.grade === g);
  if (s.n) console.log(`   grade ${g.padEnd(3)} ${fmt(s)}`);
}
const aa = by((t) => t.grade === 'A+' || t.grade === 'A');
const bc = by((t) => t.grade === 'B' || t.grade === 'C');
console.log('\n THE M95 DECISION, MEASURED');
console.log(`   A+ and A only   ${fmt(aa)}`);
console.log(`   B and C only    ${fmt(bc)}`);
console.log(`   -> dropping B and C changes expectancy by ${(all.length ? (aa.exp - by(() => true).exp) : 0).toFixed(4)}R`);

console.log('\n DECLARED R:R vs REALISED (is the target actually reachable?)');
const withRR = all.filter((t) => t.rr_declared > 0);
if (withRR.length) {
  const avgDeclared = withRR.reduce((s, t) => s + t.rr_declared, 0) / withRR.length;
  const avgRealised = withRR.reduce((s, t) => s + t.r, 0) / withRR.length;
  console.log(`   avg declared ${avgDeclared.toFixed(2)}R   avg realised ${avgRealised.toFixed(3)}R   ratio ${(avgRealised / avgDeclared).toFixed(3)}`);
  const hitT = all.filter((t) => t.outcome === 'target').length;
  const hitS = all.filter((t) => t.outcome === 'stop').length;
  const open = all.filter((t) => t.outcome === 'expired').length;
  console.log(`   target ${hitT}  ·  stop ${hitS}  ·  expired ${open}`);
}

/* ---- M58: does grade-sized deployment beat flat deployment, in dollars? ---- */
// R is normalised by risk, so a sizing change cannot move expectancy measured in R.
// The measurable effects are dollar expectancy and the volatility of the equity path.
const BAL = 10000, PCT = 1;
const dollar = (tr, m) => BAL * (PCT / 100) * m * tr.r;
function pathStats(trades, m) {
  let eq = 0, peak = 0, maxDD = 0;
  const pnl = trades.map((t) => dollar(t, m));
  for (const p of pnl) { eq += p; if (eq > peak) peak = eq; if (peak - eq > maxDD) maxDD = peak - eq; }
  const mean = pnl.reduce((a, b) => a + b, 0) / (pnl.length || 1);
  const sd = Math.sqrt(pnl.reduce((a, b) => a + (b - mean) * (b - mean), 0) / (pnl.length || 1));
  return { total: eq, maxDD, sd, perTrade: mean };
}
const flat = pathStats(all, 1);
// sized: apply the engine's own per-grade multiplier
let eqS = 0, peakS = 0, maxDDS = 0;
const pnlS = all.map((t) => dollar(t, t.mult));
for (const p of pnlS) { eqS += p; if (eqS > peakS) peakS = eqS; if (peakS - eqS > maxDDS) maxDDS = peakS - eqS; }
const meanS = pnlS.reduce((a, b) => a + b, 0) / (pnlS.length || 1);
const sdS = Math.sqrt(pnlS.reduce((a, b) => a + (b - meanS) * (b - meanS), 0) / (pnlS.length || 1));

console.log('\n M58 — FLAT vs GRADE-SIZED DEPLOYMENT ($10k account, 1% configured risk)');
console.log(`   flat  1% on every trade   total $${flat.total.toFixed(0).padStart(6)}   maxDD $${flat.maxDD.toFixed(0).padStart(5)}   sd/trade $${flat.sd.toFixed(2)}`);
console.log(`   sized by grade            total $${eqS.toFixed(0).padStart(6)}   maxDD $${maxDDS.toFixed(0).padStart(5)}   sd/trade $${sdS.toFixed(2)}`);
console.log(`   -> expectancy in R is unchanged by design (${by(() => true).exp.toFixed(4)}R); sizing moves dollars and variance`);
const delta = eqS - flat.total;
if (flat.total < 0 && delta > 0) console.log(`   -> losses reduced by $${delta.toFixed(0)} (${((1 - eqS / flat.total) * 100).toFixed(1)}%); drawdown down $${(flat.maxDD - maxDDS).toFixed(0)}, per-trade sd down $${(flat.sd - sdS).toFixed(2)}`);
else if (delta < 0) console.log(`   -> costs $${Math.abs(delta).toFixed(0)} of profit (the price of sizing down B and C), but drawdown down $${(flat.maxDD - maxDDS).toFixed(0)}`);
else console.log(`   -> no change in dollars`);

console.log('\n PER-SEED (is one series dominating the result?)');
for (let s = 1; s <= SEEDS; s++) console.log(`   seed ${s}  ${fmt(by((t) => t.seed === s))}`);

console.log('\n⚠ Synthetic data. This measures internal consistency of the entry/stop/target');
console.log('  logic, NOT real-market edge. Do not quote these figures as performance.\n');
process.exit(0);
