CREATE TABLE accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  broker TEXT DEFAULT '',
  account_type TEXT DEFAULT 'live',          -- live | demo | prop
  currency TEXT DEFAULT 'USD',
  starting_balance REAL DEFAULT 10000,
  current_balance REAL DEFAULT 10000,
  risk_per_trade_pct REAL DEFAULT 1.0,
  daily_loss_limit_pct REAL DEFAULT 3.0,
  max_drawdown_pct REAL DEFAULT 10.0,
  profit_target_pct REAL DEFAULT 8.0,
  is_default INTEGER DEFAULT 0,
  archived INTEGER DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE bot_signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    timeframe TEXT NOT NULL,
    dir INTEGER NOT NULL,
    side TEXT NOT NULL,
    grade TEXT,
    score REAL,
    p_win REAL,
    entry REAL, stop REAL, t1 REAL, t2 REAL,
    rr_primary REAL, rr_final REAL,
    mechanics REAL,
    sentiment TEXT,           -- the read-aloud headline at the time
    status TEXT NOT NULL DEFAULT 'pending',   -- pending | win | loss | no_fill | expired
    outcome_r REAL,
    outcome_note TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    resolved_at TEXT
  );
CREATE TABLE goals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  metric TEXT DEFAULT 'net_pnl',              -- net_pnl | expectancy_r | win_rate | profit_factor | adherence | trades
  target REAL NOT NULL DEFAULT 0,
  period TEXT DEFAULT 'month',                -- month | quarter | year
  due_date TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  done INTEGER DEFAULT 0
);
CREATE TABLE instruments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,                            -- NULL = global preset
  symbol TEXT NOT NULL,
  name TEXT DEFAULT '',
  asset_class TEXT NOT NULL DEFAULT 'stocks',
  exchange TEXT DEFAULT '',
  currency TEXT DEFAULT 'USD',
  tick_size REAL DEFAULT 0.01,
  pip_size REAL DEFAULT 0.01,
  value_per_point REAL DEFAULT 1,
  unit TEXT DEFAULT 'units',
  UNIQUE(user_id, symbol)
);
CREATE TABLE journal_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id INTEGER REFERENCES accounts(id) ON DELETE CASCADE,
  entry_date TEXT NOT NULL,                   -- YYYY-MM-DD
  market_bias TEXT DEFAULT '',                -- bullish / bearish / neutral / choppy
  mood INTEGER,                               -- 1-5
  energy INTEGER,                             -- 1-5
  focus TEXT DEFAULT '',
  plan TEXT DEFAULT '',
  review TEXT DEFAULT '',
  lessons TEXT DEFAULT '',
  tomorrow TEXT DEFAULT '',
  screen_time_minutes INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(user_id, entry_date)
);
CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE rule_checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trade_id INTEGER NOT NULL REFERENCES trades(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  passed INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT NOT NULL
);
CREATE TABLE strategies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  market_conditions TEXT DEFAULT '',          -- trending / ranging / volatile / news
  timeframes TEXT DEFAULT '',
  entry_rules TEXT DEFAULT '[]',              -- JSON array of strings
  exit_rules TEXT DEFAULT '[]',
  checklist TEXT DEFAULT '[]',                -- JSON array of strings (pre-trade)
  risk_rules TEXT DEFAULT '',
  target_r_multiple REAL DEFAULT 2.0,
  colour TEXT DEFAULT '#4f8cff',
  active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  symbol TEXT NOT NULL,
  asset_class TEXT DEFAULT 'stocks',
  direction TEXT NOT NULL DEFAULT 'long',
  status TEXT NOT NULL DEFAULT 'closed',      -- open | closed
  opened_at TEXT NOT NULL,
  closed_at TEXT,
  entry REAL NOT NULL,
  exit REAL,
  stop REAL,
  target REAL,
  size REAL NOT NULL DEFAULT 0,
  fees REAL DEFAULT 0,
  gross_pnl REAL DEFAULT 0,
  net_pnl REAL DEFAULT 0,
  risk_amount REAL DEFAULT 0,
  r_multiple REAL DEFAULT 0,
  planned_r REAL,
  mae_r REAL,                                 -- worst excursion in R (negative number)
  mfe_r REAL,                                 -- best excursion in R (positive number)
  stop_moved INTEGER DEFAULT 0,
  exit_reason TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  strategy_id INTEGER REFERENCES strategies(id) ON DELETE SET NULL,
  strategy_name TEXT DEFAULT '',
  setup_grade TEXT DEFAULT '',                -- A+ / A / B / C
  session TEXT DEFAULT '',
  timeframes TEXT DEFAULT '',
  emotion_before TEXT DEFAULT '',
  emotion_after TEXT DEFAULT '',
  confidence INTEGER,                         -- 1-5
  adherence INTEGER,                          -- 1-5 rule-adherence self score
  mistakes TEXT DEFAULT '',                   -- comma separated
  tags TEXT DEFAULT '',                       -- comma separated
  thesis TEXT DEFAULT '',
  lesson TEXT DEFAULT '',
  execution_notes TEXT DEFAULT '',
  screenshot_url TEXT DEFAULT '',
  manual_mae REAL,                            -- price values if user knows excursions
  manual_mfe REAL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE tv_alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tv_symbol TEXT DEFAULT '',
  symbol TEXT DEFAULT '',
  known INTEGER DEFAULT 0,
  action TEXT DEFAULT '',
  price REAL,
  timeframe TEXT DEFAULT '',
  note TEXT DEFAULT '',
  raw TEXT DEFAULT '',
  alert_time TEXT,
  received_at TEXT NOT NULL DEFAULT (datetime('now')),
  handled INTEGER DEFAULT 0,
  error TEXT,
  signal_id INTEGER,
  result TEXT
);
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  settings TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE watchlist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  symbol TEXT NOT NULL,
  asset_class TEXT DEFAULT 'stocks',
  thesis TEXT DEFAULT '',
  bias TEXT DEFAULT 'neutral',
  key_level TEXT DEFAULT '',
  catalyst TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(user_id, symbol)
);
CREATE TABLE webhook_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token TEXT UNIQUE NOT NULL,
  label TEXT DEFAULT 'TradingView',
  analyse INTEGER DEFAULT 1,                   -- run the bot on every alert
  autocreate INTEGER DEFAULT 0,                -- log the plan as a tracked signal
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_used_at TEXT,
  uses INTEGER DEFAULT 0
);
CREATE INDEX idx_bot_signals_user ON bot_signals(user_id, status);
CREATE INDEX idx_trades_account ON trades(account_id);
CREATE INDEX idx_trades_symbol ON trades(symbol);
CREATE INDEX idx_trades_user_date ON trades(user_id, opened_at);
CREATE INDEX idx_tv_alerts_user ON tv_alerts(user_id, id DESC);
