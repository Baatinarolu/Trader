'use strict';
/**
 * ─────────────────────────────────────────────────────────────────────────────
 *  ENTRY MODEL (playlist episodes 18, 20, 25, 31 — the "sniper" model)
 * ─────────────────────────────────────────────────────────────────────────────
 *
 *  Turns an SMC analysis into concrete, ranked trade plans:
 *
 *      HTF bias  ->  sweep  ->  displacement  ->  zone (OB/FVG)  ->  retest entry
 *      stop beyond the sweep/zone, target the opposing liquidity, min 1:2
 *
 *  Every plan carries:
 *    - a score (0-100) and a letter grade (A+ / A / B / C / no-trade)
 *    - the confluence checklist that produced it (so the trader can audit the bot)
 *    - exact entry / stop / targets with R:R per target
 *    - a position-size risk plan in the journal's own instrument maths
 *    - invalidation + management rules
 *    - hard vetoes (news blackout, chaos volatility, chase risk, no trigger yet)
 *
 *  The model is deliberately conservative: when the trigger is not there, it says
 *  "wait" instead of inventing a trade. That is episode 19 — when not to trade.
 */

const I = require('../instruments');

const r2 = (v) => Math.round((Number(v) || 0) * 100) / 100;
const r4 = (v) => Math.round((Number(v) || 0) * 10000) / 10000;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

const GRADES = [
  { min: 86, grade: 'A+', label: 'Textbook — every box ticked' },
  { min: 72, grade: 'A', label: 'High quality — trade the plan' },
  { min: 58, grade: 'B', label: 'Tradeable — reduced size or wait for the retest' },
  { min: 44, grade: 'C', label: 'Marginal — paper/demo or half risk at most' },
  { min: -Infinity, grade: 'no-trade', label: 'Not an A+ setup — the edge is not there' },
];

function gradeFor(score) {
  const g = GRADES.find((x) => score >= x.min);
  return { grade: g.grade, label: g.label };
}

/** Liquidity pools that matter for a target, sorted outward from `entry`. */
function targetPools(analysis, dir, entry) {
  const pools = (analysis.liquidity && analysis.liquidity.pools) || [];
  const outward = pools
    .filter((p) => (dir > 0 ? p.price > entry : p.price < entry))
    .filter((p) => p.strength >= 0.5)
    .sort((a, b) => (dir > 0 ? a.price - b.price : b.price - a.price));
  const seen = new Set();
  const out = [];
  for (const p of outward) {
    const key = p.price.toFixed(5);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(p);
  }
  return out;
}

/**
 * Build trade candidates for both directions.
 *
 * @param {object} analysis  output of smc.analyse()
 * @param {object} ctx  { price, atr, bias, biasReason, indicators, momentum, balance, riskPct,
 *                        valuePerPoint, assetClass, symbol, newsBlackout, maxRiskPct, minRR,
 *                        topdown }   topdown = the method gate (topdown.js build()):
 *                                    when it blocks, the verdict is NO TRADE no matter how
 *                                    good the setup scores, and when it carries a direction
 *                                    only that side can be armed.
 * @returns {{candidates:Array, verdict:object}}
 */
function buildSetups(analysis, ctx = {}) {
  const price = Number(ctx.price || (analysis && analysis.price));
  const atr = Number(ctx.atr || (analysis && analysis.atr)) || price * 0.001;
  const bias = Number(ctx.bias || 0);            // -1 / 0 / +1 from the MTF + momentum layer
  const minRR = Number(ctx.minRR || 2);
  const sessions = (analysis && analysis.sessions) || {};
  const strike = sessions.quality != null ? sessions.quality : 0.5;
  const blackout = ctx.newsBlackout || null;
  const ind = ctx.indicators || null;
  const momentum = ctx.momentum || null;
  const td = ctx.topdown || null;                   // the method gate

  const candidates = [];
  const vetoes = [];

  for (const dir of [1, -1]) {
    const long = dir > 0;
    const side = long ? 'buy' : 'sell';
    const checks = [];
    const add = (key, label, pass, weight, detail) => checks.push({ key, label, pass: !!pass, weight, detail: detail || null });

    /* ---------------------------------------------------------------- 1. trigger: sweep */
    const sweeps = ((analysis && analysis.sweeps) || []).filter((s) => s.dir === dir);
    const recentSweep = sweeps.find((s) => s.bars_ago <= 25) || null;
    const sweepQuality = recentSweep ? clamp(recentSweep.wick_atr / 1.2, 0.3, 1.2) : 0;
    add('sweep', long ? 'Sell-side liquidity was swept (stops taken)' : 'Buy-side liquidity was swept (stops taken)',
      !!recentSweep, 18, recentSweep ? `${recentSweep.label} · ${recentSweep.wick_atr} ATR wick · ${recentSweep.bars_ago} bars ago` : 'No sweep of the opposing liquidity yet — the model has no trigger.');

    /* ------------------------------------------------------- 2. displacement after sweep */
    const disps = ((analysis && analysis.displacement) || []).filter((d) => d.dir === dir);
    const disp = disps.find((d) => !recentSweep || d.i > recentSweep.i) || disps[0] || null;
    add('displacement', 'Displacement leg in your direction',
      !!disp, 15, disp ? `${disp.rangeAtr} ATR expansion bar, ${(disp.bodyRatio * 100).toFixed(0)}% body` : 'No expansion bar — price is drifting, not displacing.');

    /* ------------------------------------------------------------------- 3. the zone */
    const obs = ((analysis && analysis.order_blocks) || []).filter((z) => z.dir === dir && !z.breached);
    const fvgs = ((analysis && analysis.fvgs) || []).filter((g) => g.dir === dir && !g.filled);
    // prefer a fresh, strong OB with an unfilled FVG overlapping or nested
    const scored = obs.map((z) => {
      const overlap = fvgs.find((g) => g.bottom <= z.top && g.top >= z.bottom);
      const reach = z.distance_atr;                          // how far price is from the zone
      const proximity = clamp(1 - reach / 6, 0, 1);          // within 6 ATR is "reachable"
      const score = z.strength + (z.fresh ? 0.35 : 0) + (overlap ? 0.3 : 0) + proximity * 0.5;
      return { zone: z, overlap, score, reach };
    }).sort((a, b) => b.score - a.score);
    const bestOB = scored[0] || null;
    const bestFvg = fvgs.filter((g) => !bestOB || !(bestOB.overlap && bestOB.overlap.i === g.i)).sort((a, b) => b.size_atr - a.size_atr)[0] || null;

    const zone = bestOB ? { kind: 'order_block', top: bestOB.zone.top, bottom: bestOB.zone.bottom, mid: bestOB.zone.mid, entry: bestOB.zone.body_mid, meta: bestOB.zone, overlap: bestOB.overlap }
      : bestFvg ? { kind: 'fvg', top: bestFvg.top, bottom: bestFvg.bottom, mid: bestFvg.mid, entry: bestFvg.mid, meta: bestFvg, overlap: null }
        : null;

    add('zone', long ? 'Demand zone (order block / FVG) to buy from' : 'Supply zone (order block / FVG) to sell from',
      !!zone, 16, zone ? `${zone.kind === 'order_block' ? 'Order block' : 'FVG'} ${r4(zone.bottom)} – ${r4(zone.top)}${zone.overlap ? ', nested FVG' : ''}${zone.meta.fresh ? ', fresh' : `, already tested ${zone.meta.tests}×`}` : 'No unmitigated zone in this direction.');

    if (zone && zone.overlap) add('nested', 'Zone + imbalance overlap (confluence)', true, 8, 'The order block contains an unfilled FVG — two reasons for price to react at the same price.');

    /* --------------------------------------------------------- 4. discount / premium */
    const pd = (analysis && analysis.premium_discount) || null;
    const inGoodHalf = pd ? (long ? pd.position_pct < 55 : pd.position_pct > 45) : false;
    add('range', long ? 'Price is in discount of the dealing range' : 'Price is in premium of the dealing range',
      inGoodHalf, 10, pd ? `${pd.position_pct}% of the range ${r4(pd.range_low)} – ${r4(pd.range_high)} (${pd.zone})${pd.ote === (long ? 'long' : 'short') ? ' · inside the 0.62–0.79 OTE band' : ''}` : 'Dealing range not available.');

    /* ------------------------------------------------------------- 5. trend alignment */
    const trend = analysis && analysis.structure ? analysis.structure.trend : 'ranging';
    const trendAligned = (long && trend === 'bullish') || (!long && trend === 'bearish');
    const htfTrend = analysis && analysis.htf_structure ? analysis.htf_structure.trend : null;
    const htfAligned = htfTrend ? ((long && htfTrend === 'bullish') || (!long && htfTrend === 'bearish')) : null;
    add('structure', 'Internal structure agrees', trendAligned, 12, `Structure reads ${trend}${analysis.structure.last_break ? ` after a ${analysis.structure.last_break.type} ${analysis.structure.last_break.dir} ${analysis.structure.last_break.bars_ago} bars ago${analysis.structure.last_break.mss ? ' (MSS — sweep then shift)' : ''}` : ''}.`);
    if (htfAligned !== null) add('htf', 'Higher-timeframe trend agrees', htfAligned, 10, `HTF structure reads ${htfTrend}.`);

    /* ------------------------------------------------------------- 6. higher-timeframe bias */
    add('bias', 'Multi-timeframe indicator bias agrees', bias !== 0 && Math.sign(bias) === dir, 12,
      ctx.biasReason || (bias === 0 ? 'Indicators are mixed — no directional edge.' : null));

    /* ------------------------------------------------------------------ 7. oscillators */
    const rsi = ind && ind.ind ? ind.ind.rsi14 : null;
    const macdOk = ind && ind.ind && ind.ind.macd ? ((long && ind.ind.macd.hist > 0) || (!long && ind.ind.macd.hist < 0)) : null;
    const rsiOk = rsi != null ? (long ? rsi < 62 : rsi > 38) : null;   // not chasing extended momentum
    if (rsi != null || macdOk != null) {
      add('momentum', 'Momentum not extended against you', (rsiOk !== false) && (macdOk !== false), 8,
        `RSI ${rsi != null ? r2(rsi) : 'n/a'}${macdOk != null ? `, MACD histogram ${macdOk ? 'supports' : 'opposes'}` : ''}${rsi != null && !rsiOk ? ' — you would be buying/selling into an over-extended oscillator' : ''}.`);
    }

    /* ------------------------------------------------------- 8. session / killzone */
    add('session', 'Inside a high-probability killzone', !!sessions.in_killzone, 8,
      sessions.note || 'Session filter unavailable.');

    /* ---------------------------------------------------------------- 9. news */
    add('news', 'No high-impact news in the window', !blackout, 10,
      blackout ? blackout : 'No high-impact releases due in the next 60 minutes.');

    /* ------------------------------------------------------------- 10. volatility */
    const atrRank = ind && ind.ind ? ind.ind.atr_rank : null;
    add('volatility', 'Volatility tradeable (not chaos)', atrRank == null || atrRank <= 90, 6,
      atrRank == null ? null : `ATR is at the ${atrRank}th percentile of the last 120 bars.`);

    /* --------------------------------------------------------- 11. liquidity runway */
    let levels = null;
    if (zone) {
      const entry = zone.entry;
      const stopBase = long ? Math.min(zone.bottom, recentSweep ? recentSweep.extreme : zone.bottom) : Math.max(zone.top, recentSweep ? recentSweep.extreme : zone.top);
      const buffer = atr * 0.18;
      const stop = long ? stopBase - buffer : stopBase + buffer;
      const risk = Math.abs(entry - stop);
      const pools = targetPools(analysis, dir, entry);
      const targets = [];
      for (const p of pools) {
        const reward = Math.abs(p.price - entry);
        const rr = risk ? reward / risk : 0;
        if (rr < 0.9) continue;                       // ignore pools the entry already sits on
        targets.push({ label: p.label, kind: p.kind, price: r4(p.price), rr: r2(rr), strength: p.strength, touches: p.touches || null });
      }
      // dealing-range extreme as a structural target
      if (pd) {
        const extreme = long ? pd.range_high : pd.range_low;
        const reward = Math.abs(extreme - entry);
        if (reward > 0) {
          const rr = risk ? reward / risk : 0;
          if (rr >= 1 && !targets.some((t) => Math.abs(t.price - extreme) < atr * 0.3)) {
            targets.push({ label: long ? 'Dealing range high' : 'Dealing range low', kind: 'range', price: r4(extreme), rr: r2(rr), strength: 0.9 });
          }
        }
      }
      targets.sort((a, b) => a.rr - b.rr);
      // The FIRST pool is a wall, not a nuisance: price usually reacts there. The model
      // banks a partial on it, protects the trade, and runs the rest to the 2R+ pool.
      const first = targets[0] || null;
      const runner = targets.find((t) => t.rr >= minRR) || targets[targets.length - 1] || null;
      const wallRisk = first && first.rr < 1.3 ? first : null;

      add('runway', `Open runway to opposing liquidity (final target ≥ 1:${minRR})`, !!runner && runner.rr >= minRR, 14,
        runner && runner.rr >= minRR
          ? `Partial at ${first.label} (${first.rr}R), runner to ${runner.label} at ${runner.price} = ${runner.rr}R`
          : first ? `The furthest real pool (${first.label}, ${first.price}) is only ${first.rr}R away — not enough runway for the risk taken.`
            : 'No liquidity pool beyond entry to target — no reason for price to travel.');

      // target ladder: T1 (wall, partial), T2 (runner), T3 (extension if one exists)
      const ladder = [];
      if (first) ladder.push({ ...first, role: 'T1' });
      if (runner && (!first || runner.rr > first.rr + 0.3)) ladder.push({ ...runner, role: 'T2' });
      const beyond = targets.filter((t) => runner && t.rr > runner.rr + 0.6).slice(0, 1);
      beyond.forEach((t) => ladder.push({ ...t, role: 'T3' }));
      if (!ladder.length) ladder.push({ label: '1.5R measured move', kind: 'measured', price: r4(entry + dir * risk * 1.5), rr: 1.5, role: 'T1' });
      const rrPrimary = ladder[0].rr;
      const rrFinal = ladder[ladder.length - 1].rr;

      // entry status: are we at the zone, or chasing?
      let entryStatus, entryNote;
      if (long) {
        if (price < zone.bottom - atr * 0.2) { entryStatus = 'invalid'; entryNote = 'Price is already below the zone — the level failed; this is not a retest, it is a breakdown.'; }
        else if (price <= zone.top) { entryStatus = 'at-entry'; entryNote = 'Price is trading inside the zone — the retest is happening now.'; }
        else if (price - zone.top <= atr * 1.5) { entryStatus = 'approaching'; entryNote = 'Price is close, waiting for the retrace into the zone.'; }
        else { entryStatus = 'waiting'; entryNote = `Price is ${r2((price - zone.top) / atr)} ATR above the zone — do not chase; set an alert at ${r4(zone.top)}.`; }
      } else {
        if (price > zone.top + atr * 0.2) { entryStatus = 'invalid'; entryNote = 'Price closed above the supply zone — the level failed.'; }
        else if (price >= zone.bottom) { entryStatus = 'at-entry'; entryNote = 'Price is trading inside the supply zone — the retest is happening now.'; }
        else if (zone.bottom - price <= atr * 1.5) { entryStatus = 'approaching'; entryNote = 'Price is close, waiting for the pullback into the zone.'; }
        else { entryStatus = 'waiting'; entryNote = `Price is ${r2((zone.bottom - price) / atr)} ATR below the zone — do not chase; set an alert at ${r4(zone.bottom)}.`; }
      }
      // Distance still to travel to the zone we would enter at. An FVG-only read has
      // no order-block `reach` — measure to its near edge instead of dereferencing null.
      const zoneReach = bestOB ? bestOB.reach
        : bestFvg ? Math.abs((long ? bestFvg.top : bestFvg.bottom) - price) / (atr || 1)
          : 6;
      add('entry', 'Entry not chased (price at/near the zone)', entryStatus !== 'waiting' || zoneReach <= 2.5, 8, entryNote);
      add('management', 'Risk plan protects the trade at the first pool', rrFinal >= minRR, 0,
        `Take 50% at ${ladder[0].label} (${rrPrimary}R), move the stop to break-even, run the rest to ${ladder[ladder.length - 1].label} (${rrFinal}R).`);
      if (entryStatus === 'invalid') add('entry_valid', 'Zone not already invalidated', false, 0, entryNote);

      levels = {
        dir, side, entry: r4(entry), entry_zone: [r4(zone.bottom), r4(zone.top)], entry_kind: zone.kind,
        stop: r4(stop), risk: r4(risk), risk_atr: r2(risk / atr),
        stop_reason: recentSweep && Math.abs(stopBase - recentSweep.extreme) < 1e-9
          ? `Beyond the sweep extreme (${r4(stopBase)}) + ${r2(atr * 0.18)} buffer`
          : `Beyond the ${zone.kind === 'order_block' ? 'order block' : 'FVG'} ${long ? 'low' : 'high'} ${r4(stopBase)} + ${r2(atr * 0.18)} buffer`,
        targets: ladder, primary_target: ladder[0] ? { ...ladder[0] } : null,
        rr_primary: rrPrimary, rr_final: rrFinal,
        management: {
          partial_at: ladder[0] ? { price: ladder[0].price, rr: ladder[0].rr, label: ladder[0].label, size: '50%' } : null,
          break_even_after: ladder[0] ? ladder[0].price : null,
          runner_target: ladder[ladder.length - 1] ? { price: ladder[ladder.length - 1].price, rr: ladder[ladder.length - 1].rr, label: ladder[ladder.length - 1].label, size: ladder.length > 1 ? '50%' : '100%' } : null,
          rule: ladder.length > 1
            ? `Bank 50% at T1 (${ladder[0].rr}R) and move the stop to entry. The runner is free — let the pool at ${ladder[ladder.length - 1].price} do the work.`
            : 'Single target: manage as one position, trail behind structure after 1R.',
        },
        wall: wallRisk ? { label: wallRisk.label, price: wallRisk.price, rr: wallRisk.rr } : null,
        entry_status: entryStatus, entry_note: entryNote,
        risk_warning: risk < atr * 0.35 ? 'Stop is tighter than 0.35 ATR — normal noise can take you out. Consider using the sweep extreme instead.' : null,
        invalidation: long
          ? `A 15m close below ${r4(Math.min(zone.bottom, recentSweep ? recentSweep.extreme : zone.bottom))} invalidates the idea.`
          : `A 15m close above ${r4(Math.max(zone.top, recentSweep ? recentSweep.extreme : zone.top))} invalidates the idea.`,
      };
    } else {
      add('runway', 'Open runway to opposing liquidity', false, 14, 'No zone, so no defined risk — the model needs a level to trade against.');
    }

    /* ------------------------------------------------------------------- score */
    const totalW = checks.reduce((s, c) => s + c.weight, 0) || 1;
    const got = checks.reduce((s, c) => s + (c.pass ? c.weight : 0), 0);
    let score = (got / totalW) * 100;
    // killzone is a real multiplier in the curriculum: outside it, size/edge drops
    score = score * (0.82 + 0.18 * strike);
    // a missing trigger or zone is disqualifying regardless of the rest
    const hasTrigger = checks.find((c) => c.key === 'sweep').pass;
    const hasZone = checks.find((c) => c.key === 'zone').pass;
    if (!hasTrigger) score = Math.min(score, 38);
    if (!hasZone) score = Math.min(score, 34);
    if (levels && levels.rr_final > 0 && levels.rr_final < minRR) score = Math.min(score, 45);
    if (levels && levels.entry_status === 'invalid') score = Math.min(score, 20);
    if (blackout) score = Math.min(score, 40);
    if (levels && levels.entry_status === 'waiting') score = Math.min(score, 66); // great idea, not yet valid
    score = round1(clamp(score, 0, 100));

    const g = gradeFor(score);

    /* --------------------------------------------------------------- risk plan */
    let risk = null;
    if (levels) {
      const balance = Number(ctx.balance || 0);
      const riskPct = Number(ctx.riskPct || 1);
      const vpp = Number(ctx.valuePerPoint || 1);
      if (balance > 0 && vpp > 0) {
        const sizing = I.positionSize({
          balance, riskPct, entry: levels.entry, stop: levels.stop,
          value_per_point: vpp, asset_class: ctx.assetClass || 'stocks',
        });
        const perR = sizing.riskAmount || 0;
        risk = {
          balance: r2(balance), risk_pct: riskPct, risk_amount: r2(balance * riskPct / 100),
          size: sizing.size, unit: sizing.unit, actual_risk: perR, per_unit: sizing.perUnit,
          note: sizing.note || null,
          at_targets: (levels.targets || []).map((t) => ({ role: t.role, price: t.price, rr: t.rr, pnl: r2(perR * t.rr) })),
          managed: levels.management && levels.management.runner_target
            ? r2(perR * ((levels.rr_primary * 0.5) + (levels.rr_final * 0.5)))
            : r2(perR * (levels.rr_primary || 0)),
        };
      }
    }

    candidates.push({
      dir, side, score, grade: g.grade, grade_label: g.label,
      ok: g.grade !== 'no-trade' && (!levels || levels.entry_status !== 'invalid'),
      checks,
      passed: checks.filter((c) => c.pass).length,
      total_checks: checks.length,
      levels, risk,
      /** what to do right now, in one line */
      action: !levels ? 'Stand down — no zone to trade against.'
        : levels.entry_status === 'at-entry' && g.grade !== 'no-trade' ? `Arm the entry: limit at ${levels.entry}, stop ${levels.stop}, first target ${levels.targets[0] ? levels.targets[0].price : '—'}.`
          : levels.entry_status === 'approaching' ? `Get ready: price is approaching the ${levels.entry_kind === 'order_block' ? 'order block' : 'FVG'}. Set an alert at ${long ? levels.entry_zone[1] : levels.entry_zone[0]}.`
            : levels.entry_status === 'waiting' ? `Wait for the retrace to ${levels.entry_zone[0]}–${levels.entry_zone[1]}. Chasing here breaks the model's edge.`
              : 'Invalidated — remove the level and re-map.',
      why: checks.filter((c) => c.pass).map((c) => c.detail).filter(Boolean),
      why_not: checks.filter((c) => !c.pass).map((c) => c.detail || c.label),
    });
  }

  candidates.sort((a, b) => b.score - a.score);

  /* --------------------------------------------------------------- top verdict */
  let best = candidates[0] || null;
  const buy = candidates.find((c) => c.dir === 1);
  const sell = candidates.find((c) => c.dir === -1);

  // ── the method gate ─────────────────────────────────────────────────────────
  // The playlist's top-down method decides whether a direction may be traded at
  // all. When it has not fired, no setup grade can override it: the answer is
  // wait, and we say exactly which step is outstanding.
  const method = td ? {
    status: td.status, direction: td.direction, blocked: !!td.blocked,
    conviction: td.conviction || null,
    score: td.score, grade: td.grade, headline: td.headline,
    pending_step: (td.steps || []).find((s) => !s.done) || null,
    checks: td.checks || [],
  } : null;
  if (td && td.direction !== 0) {
    const aligned = candidates.find((c) => c.dir === td.direction);
    if (aligned) best = aligned;                    // the higher timeframe chooses the side
  }
  const rawBest = candidates[0] || null;
  const setupAction = !rawBest || rawBest.grade === 'no-trade' ? null : (rawBest.dir > 0 ? 'BUY' : 'SELL');
  const methodBlocked = !!(td && (td.blocked || (td.direction !== 0 && (!best || best.dir !== td.direction))));

  let verdict;
  if (methodBlocked) {
    const why = td.blocked
      ? `${(td.conflicts || []).filter((c) => c.blocks_trade).map((c) => c.resolution).join(' ') || 'the higher-timeframe steps are not complete'}`
      : `the setup model likes the ${rawBest.side}, but the ${td.layers && td.layers.bias ? td.layers.bias.tf : 'higher timeframe'} says ${td.direction > 0 ? 'long' : 'short'}. Taking the other side is trading the small chart against the boss.`;
    verdict = {
      action: 'NO TRADE', dir: 0,
      grade: best ? best.grade : (rawBest ? rawBest.grade : 'no-trade'),
      score: best ? best.score : 0,
      headline: `Method says wait — ${td.headline}`,
      detail: `${why}${pendingStep(td)}`,
      next_trigger: [td.playbook && td.playbook.length ? td.playbook[0] : null, nextTriggerHint(analysis)].filter(Boolean),
      source: 'topdown-gate', method, setup_action: setupAction,
      setup_dir: rawBest ? rawBest.dir : 0,
    };
  } else if (!best || best.grade === 'no-trade') {
    verdict = {
      action: 'NO TRADE', dir: 0, grade: best ? best.grade : 'no-trade', score: best ? best.score : 0,
      headline: 'No A-grade setup right now — the model says wait.',
      detail: best ? best.why_not.slice(0, 4).join(' ') : 'Not enough data.',
      next_trigger: nextTriggerHint(analysis),
      source: 'setup-model', method, setup_action: setupAction,
    };
  } else {
    const t1 = best.levels && best.levels.targets && best.levels.targets[0] ? best.levels.targets[0] : null;
    const headline = best.levels
      ? `${best.grade} ${best.side} setup — partial ${best.levels.rr_primary}R at ${t1 ? t1.label : 'the first pool'}, runner to ${best.levels.rr_final}R`
      : `${best.grade} ${best.side} setup`;
    const methodOk = !td ? null : (td.direction !== 0 && td.direction === best.dir);
    verdict = {
      action: best.dir > 0 ? 'BUY' : 'SELL', dir: best.dir, grade: best.grade, score: best.score,
      headline: methodOk ? `${headline} — on the ${td.layers && td.layers.bias ? td.layers.bias.tf : 'higher timeframe'} side of the method` : headline,
      detail: best.action + (methodOk && td.conviction && td.conviction.tier === 'B' ? ` Sizing: ${td.conviction.size_hint}.` : ''),
      next_trigger: nextTriggerHint(analysis),
      source: methodOk ? 'method-aligned' : 'setup-model', method, setup_action: setupAction,
      method_aligned: methodOk,
    };
  }

  return {
    candidates, verdict, method,
    buy_score: buy ? buy.score : 0, sell_score: sell ? sell.score : 0,
    grade_scale: GRADES.map((g) => ({ grade: g.grade, label: g.label, min: g.min === -Infinity ? 0 : g.min })),
    filters: {
      killzone: sessions.killzone || 'outside killzone',
      killzone_quality: strike,
      news_blackout: blackout || null,
      min_rr: minRR,
    },
  };
}

function nextTriggerHint(analysis) {
  if (!analysis) return null;
  const hints = [];
  const sweeps = analysis.sweeps || [];
  const recent = sweeps[0];
  if (!recent) hints.push('No liquidity sweep yet — wait for stops to be taken (equal highs/lows, PDH/PDL, session extremes).');
  const disp = (analysis.displacement || [])[0];
  if (!disp) hints.push('No displacement leg yet — wait for an expansion bar that breaks structure.');
  const obs = (analysis.order_blocks || []).filter((z) => !z.breached && z.fresh);
  if (!obs.length) hints.push('No fresh, unmitigated order block — the zones on the chart have already been used.');
  const s = analysis.sessions || {};
  if (!s.in_killzone) hints.push(s.best_time || 'Wait for a killzone (London 07:00 or NY 12:00 UTC).');
  return hints.length ? hints : null;
}

function round1(v) { return Math.round(v * 10) / 10; }


/** " Outstanding step: <title>." — or nothing when every step is done. */
function pendingStep(td) {
  const open = ((td && td.steps) || []).find((s) => !s.done);
  return open && open.title ? ` Outstanding step: ${open.title}.` : '';
}

module.exports = { buildSetups, gradeFor, GRADES, targetPools };
