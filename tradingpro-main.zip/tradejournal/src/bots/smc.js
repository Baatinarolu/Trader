'use strict';
/**
 * ─────────────────────────────────────────────────────────────────────────────
 *  SMC ENGINE — the market mechanics taught in the "Market Mechanics Mentorship"
 *  playlist (Brad Goh / The Trading Geek), expressed as pure functions.
 * ─────────────────────────────────────────────────────────────────────────────
 *
 *  Pipeline the curriculum teaches, and the pipeline implemented here:
 *
 *    1. bias      higher-timeframe direction (delegated: momentum.js / MTF)
 *    2. structure swing points -> HH/HL/LH/LL -> BOS / CHoCH / MSS
 *    3. liquidity equal highs/lows, PDH/PDL, PWH/PWL, session extremes, inducement
 *    4. sweep     price wicks through a pool and CLOSES BACK INSIDE (stop hunt)
 *    5. displacement  large-bodied expansion bar that breaks structure
 *    6. imbalance order blocks + fair value gaps left behind by the displacement
 *    7. entry     retrace into the zone (OB 50% / FVG CE), stop beyond sweep/zone,
 *                 target the opposing liquidity pool — minimum 1:2
 *    8. filters   killzones, premium/discount, news blackout, CRT range play
 *
 *  Everything here is deterministic and side-effect free: same candles in, same
 *  analysis out. No opinions on size or money — that lives in setup.js.
 */

const I = require('../indicators');

const r2 = (v) => Math.round((Number(v) || 0) * 100) / 100;
const r4 = (v) => Math.round((Number(v) || 0) * 10000) / 10000;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/* ══════════════════════════════════════════════════════════════ 1. SWINGS */

/**
 * Fractal swing points. A swing high is a bar whose high is the highest of the
 * `strength` bars either side of it (right side must be strictly lower so that
 * plateaus produce one point, not two).
 * @returns {Array<{i:number,t:number,price:number,type:'high'|'low',strength:number}>}
 */
function findSwings(candles, strength = 2) {
  const out = [];
  const n = candles.length;
  for (let i = strength; i < n - strength; i++) {
    let isHigh = true, isLow = true;
    for (let j = i - strength; j <= i + strength; j++) {
      if (j === i) continue;
      if (candles[j].h >= candles[i].h) isHigh = false;
      if (candles[j].l <= candles[i].l) isLow = false;
    }
    if (isHigh) out.push({ i, t: candles[i].t, price: candles[i].h, type: 'high', strength });
    if (isLow) out.push({ i, t: candles[i].t, price: candles[i].l, type: 'low', strength });
  }
  return out;
}

/** Keep only alternating highs/lows — keeps the most extreme when two of a kind repeat. */
function alternate(swings) {
  const out = [];
  for (const s of swings) {
    const lastS = out[out.length - 1];
    if (!lastS || lastS.type !== s.type) { out.push(s); continue; }
    const better = s.type === 'high' ? s.price > lastS.price : s.price < lastS.price;
    if (better) out[out.length - 1] = s;
  }
  return out;
}

/* ══════════════════════════════════════════════ 2. MARKET STRUCTURE / BOS */

/**
 * Label swings HH / HL / LH / LL and derive trend, BOS, CHoCH and MSS events.
 * @param {Array} candles
 * @param {Array} swings  alternating swings (see alternate())
 */
function marketStructure(candles, swings) {
  const labels = [];
  let prevHigh = null, prevLow = null;
  for (const s of swings) {
    if (s.type === 'high') {
      const tag = prevHigh === null ? 'H' : s.price > prevHigh.price ? 'HH' : s.price < prevHigh.price ? 'LH' : 'EH';
      labels.push({ ...s, label: tag });
      prevHigh = s;
    } else {
      const tag = prevLow === null ? 'L' : s.price > prevLow.price ? 'HL' : s.price < prevLow.price ? 'LL' : 'EL';
      labels.push({ ...s, label: tag });
      prevLow = s;
    }
  }

  // trend = read of the last few labelled swings
  const recent = labels.slice(-5);
  const hh = recent.filter((x) => x.label === 'HH').length, hl = recent.filter((x) => x.label === 'HL').length;
  const lh = recent.filter((x) => x.label === 'LH').length, ll = recent.filter((x) => x.label === 'LL').length;
  let trend = 'ranging';
  if (hh + hl >= 3 && hh > 0 && hl > 0) trend = 'bullish';
  else if (lh + ll >= 3 && lh > 0 && ll > 0) trend = 'bearish';
  else if (hh + hl > lh + ll + 1) trend = 'bullish';
  else if (lh + ll > hh + hl + 1) trend = 'bearish';

  // BOS / CHoCH: walk bars after each confirmed swing and look for a CLOSE beyond it
  const events = [];
  const swingHighs = labels.filter((x) => x.type === 'high');
  const swingLows = labels.filter((x) => x.type === 'low');
  const scanBreaks = (list, dir) => {
    for (let k = 0; k < list.length; k++) {
      const s = list[k];
      for (let i = s.i + 1; i < candles.length; i++) {
        const c = candles[i];
        const broke = dir === 'up' ? c.c > s.price : c.c < s.price;
        if (!broke) continue;
        // was the structure above/at this swing already bullish/bearish?
        const prior = events.filter((e) => e.i < i);
        const lastEvent = prior[prior.length - 1];
        // A break in the OPPOSITE direction to the last break = change of character.
        const isChoch = !!lastEvent && (dir === 'up' ? lastEvent.dir === 'down' : lastEvent.dir === 'up');
        events.push({
          type: isChoch ? 'CHoCH' : 'BOS',
          dir, i, t: c.t, level: r4(s.price), close: r4(c.c),
          sweptBefore: false,
        });
        break; // one break per swing level
      }
    }
    return events;
  };


  const all = [...scanBreaks(swingHighs, 'up'), ...scanBreaks(swingLows, 'down')].sort((a, b) => a.i - b.i);
  // dedupe: consecutive same-direction events closer than 3 bars collapse to the first
  const breaks = [];
  for (const e of all) {
    const lastB = breaks[breaks.length - 1];
    if (lastB && lastB.dir === e.dir && e.i - lastB.i < 3) continue;
    breaks.push(e);
  }

  // MSS = CHoCH whose break bar swept liquidity in the opposite direction first.
  // Approximate: a CHoCH is an MSS when the 5 bars before the break wick beyond the
  // prior swing of the OTHER side (a stop run) — checked in sweeps() and patched there.
  for (const e of breaks) { e.mss = e.type === 'CHoCH'; }

  const lastHigh = swingHighs[swingHighs.length - 1] || null;
  const lastLow = swingLows[swingLows.length - 1] || null;
  const lastBreak = breaks[breaks.length - 1] || null;

  return {
    labels, breaks, trend,
    last_break: lastBreak ? { type: lastBreak.type, dir: lastBreak.dir, level: lastBreak.level, t: lastBreak.t, bars_ago: candles.length - 1 - lastBreak.i, mss: !!lastBreak.mss } : null,
    recent_labels: labels.slice(-6).map((x) => ({ label: x.label, price: r4(x.price), t: x.t, type: x.type })),
    last_swing_high: lastHigh ? { price: r4(lastHigh.price), t: lastHigh.t, i: lastHigh.i, label: lastHigh.label } : null,
    last_swing_low: lastLow ? { price: r4(lastLow.price), t: lastLow.t, i: lastLow.i, label: lastLow.label } : null,
  };
}

/* ══════════════════════════════════════════════════════ 3. DISPLACEMENT */

/** Expansion bars: body dominates the range and the range beats ATR — the "engine" behind SMC. */
function findDisplacement(candles, atr, { minAtr = 1.2, minBody = 0.55 } = {}) {
  const out = [];
  for (let i = 1; i < candles.length; i++) {
    const b = candles[i];
    const range = b.h - b.l;
    const body = Math.abs(b.c - b.o);
    if (!range || !atr) continue;
    const dir = b.c > b.o ? 1 : b.c < b.o ? -1 : 0;
    if (!dir) continue;
    const bodyRatio = body / range;
    const rangeAtr = range / atr;
    if (bodyRatio >= minBody && rangeAtr >= minAtr) {
      out.push({ i, t: b.t, dir, rangeAtr: r2(rangeAtr), bodyRatio: r2(bodyRatio), close: b.c, open: b.o, high: b.h, low: b.l });
    }
  }
  return out;
}

/* ═════════════════════════════════════════════════ 4. ORDER BLOCKS / FVG */

/**
 * Order blocks: the last opposite candle before a displacement leg.
 * Bundles supply (bearish OB) and demand (bullish OB) with freshness + confluence tags.
 */
function findOrderBlocks(candles, atr, displacement, breaks, { maxAge = 250, maxBlocks = 14 } = {}) {
  const out = [];
  const n = candles.length;
  for (const d of displacement) {
    if (n - 1 - d.i > maxAge) continue;
    // walk back from the displacement bar to find the last opposite-colour candle
    let idx = -1;
    for (let j = d.i - 1; j >= Math.max(0, d.i - 6); j--) {
      const b = candles[j];
      const opposite = d.dir > 0 ? b.c < b.o : b.c > b.o;
      if (opposite) { idx = j; break; }
    }
    if (idx < 0) continue;
    const ob = candles[idx];
    const dir = d.dir > 0 ? 1 : -1; // 1 = demand (bullish OB), -1 = supply
    const top = ob.h, bottom = ob.l;
    const bodyTop = Math.max(ob.o, ob.c), bodyBottom = Math.min(ob.o, ob.c);

    // mitigation: how has price interacted with the zone SINCE the displacement leg?
    // (bars inside the leg itself are the move that created the zone, not a test)
    let tests = 0, mitigated = false, breached = false, firstTest = null;
    for (let i = Math.max(idx + 1, d.i + 1); i < n; i++) {
      const b = candles[i];
      const inside = b.l <= top && b.h >= bottom;
      if (inside && !firstTest) firstTest = i;
      if (inside) tests++;
      if (dir > 0 ? b.c < bottom : b.c > top) { breached = true; mitigated = true; }
      else if (dir > 0 ? b.l <= top : b.h >= bottom) mitigated = true;
    }
    const brokeStructure = breaks.some((x) => x.i > idx && x.i <= d.i + 1 && ((dir > 0 && x.dir === 'up') || (dir < 0 && x.dir === 'down')));
    const strength = clamp(
      0.4 + Math.min(d.rangeAtr / 3, 1) * 0.3 + (brokeStructure ? 0.2 : 0) + (tests === 0 ? 0.15 : 0) - (breached ? 0.5 : 0), 0, 1.4,
    );
    const firstTouch = firstTest;
    out.push({
      kind: 'OB', dir, side: dir > 0 ? 'demand' : 'supply',
      top: r4(top), bottom: r4(bottom), mid: r4((top + bottom) / 2),
      body_top: r4(bodyTop), body_bottom: r4(bodyBottom), body_mid: r4((bodyTop + bodyBottom) / 2),
      i: idx, t: ob.t, displacement_i: d.i, displacement_atr: d.rangeAtr,
      tests, first_touch: firstTouch, mitigated, breached, fresh: tests === 0,
      broke_structure: brokeStructure, strength: r2(strength),
      bars_ago: n - 1 - idx,
      distance_pct: r2(((dir > 0 ? top : bottom) - candles[n - 1].c) / candles[n - 1].c * 100),
      distance_atr: r2(Math.abs(((dir > 0 ? top : bottom) - candles[n - 1].c)) / (atr || 1)),
    });
  }
  // best-first: strong, fresh, not breached, near price
  out.sort((a, b) => (b.strength - (b.breached ? 1 : 0)) - (a.strength - (a.breached ? 1 : 0)));
  const seen = new Set();
  const dedup = [];
  for (const z of out) {
    const key = `${z.dir}:${z.t}:${z.bottom.toFixed(4)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    dedup.push(z);
    if (dedup.length >= maxBlocks) break;
  }
  return dedup;
}

/** Fair value gaps / imbalances — the 3-candle void displacement leaves behind. */
function findFvgs(candles, atr, { minAtr = 0.12, maxAge = 250, maxGaps = 14 } = {}) {
  const out = [];
  const n = candles.length;
  for (let i = 2; i < n; i++) {
    const a = candles[i - 2], b = candles[i - 1], c = candles[i];
    if (n - 1 - i > maxAge) continue;
    const bull = c.l > a.h;          // gap between candle A high and candle C low
    const bear = c.h < a.l;
    if (!bull && !bear) continue;
    const bottom = bull ? a.h : c.h;
    const top = bull ? c.l : a.l;
    const size = top - bottom;
    if (!atr || size < minAtr * atr) continue;
    // fill tracking
    let fillPct = 0, filled = false;
    for (let j = i + 1; j < n; j++) {
      const x = candles[j];
      if (bull) {
        if (x.l <= bottom) { filled = true; fillPct = 100; break; }
        if (x.l < top) fillPct = Math.max(fillPct, ((top - x.l) / size) * 100);
      } else {
        if (x.h >= top) { filled = true; fillPct = 100; break; }
        if (x.h > bottom) fillPct = Math.max(fillPct, ((x.h - bottom) / size) * 100);
      }
    }
    const dir = bull ? 1 : -1;
    out.push({
      kind: 'FVG', dir, side: bull ? 'bullish' : 'bearish',
      top: r4(top), bottom: r4(bottom), mid: r4((top + bottom) / 2),
      size: r4(size), size_atr: r2(size / atr), i, t: candles[i].t,
      filled, fill_pct: r2(fillPct), bars_ago: n - 1 - i,
      strength: r2(clamp(size / atr / 3 + (filled ? -0.3 : 0.1), 0, 1.4)),
    });
  }
  out.sort((a, b) => (b.size_atr - b.fill_pct / 100) - (a.size_atr - a.fill_pct / 100));
  const seen = new Set();
  const dedup = [];
  for (const g of out) {
    const key = `${g.dir}:${g.t}`;
    if (seen.has(key)) continue;
    seen.add(key); dedup.push(g);
    if (dedup.length >= maxGaps) break;
  }
  return dedup;
}

/**
 * Breaker blocks / flip zones: a zone that failed in its own direction and now acts
 * the other way. A demand OB that closes below becomes resistance (bearish breaker).
 */
function findBreakers(orderBlocks, candles, atr) {
  const out = [];
  const n = candles.length;
  for (const z of orderBlocks) {
    if (!z.breached) continue;
    let brokeAt = null;
    for (let i = z.i + 1; i < n; i++) {
      const c = candles[i];
      const through = z.dir > 0 ? c.c < z.bottom : c.c > z.top;
      if (through) { brokeAt = i; break; }
    }
    if (brokeAt === null) continue;
    // retest since the break = confirmation the flip holds
    let retested = false;
    for (let i = brokeAt + 1; i < n; i++) {
      const c = candles[i];
      if (c.h >= z.bottom && c.l <= z.top) { retested = true; break; }
    }
    out.push({
      kind: 'breaker', dir: -z.dir, side: z.dir > 0 ? 'supply' : 'demand',
      top: z.top, bottom: z.bottom, mid: z.mid, i: brokeAt, t: candles[brokeAt].t,
      origin: { top: z.top, bottom: z.bottom, side: z.side, t: z.t }, retested,
      strength: r2(clamp(z.strength + (retested ? 0.2 : 0) - 0.2, 0, 1.4)),
      bars_ago: n - 1 - brokeAt, distance_atr: r2(Math.abs(((z.dir > 0 ? z.bottom : z.top) - candles[n - 1].c)) / (atr || 1)),
    });
  }
  return out;
}

/* ══════════════════════════════════════════════════════ 5. LIQUIDITY POOLS */

const dayKey = (t) => new Date(t).toISOString().slice(0, 10);
function weekKey(t) {
  const d = new Date(t);
  const day = (d.getUTCDay() + 6) % 7; // Monday = 0
  const monday = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - day));
  return monday.toISOString().slice(0, 10);
}

/** Cluster swing levels that sit within `tol` of each other => equal highs / equal lows. */
function clusterLevels(swings, tol) {
  const sorted = [...swings].sort((a, b) => a.price - b.price);
  const clusters = [];
  for (const s of sorted) {
    const c = clusters[clusters.length - 1];
    if (c && Math.abs(s.price - c.price) <= tol) {
      c.members.push(s);
      c.price = (c.price * (c.members.length - 1) + s.price) / c.members.length;
      c.lastT = Math.max(c.lastT, s.t);
    } else {
      clusters.push({ price: s.price, members: [s], lastT: s.t, type: s.type });
    }
  }
  return clusters.map((c) => ({ ...c, touches: c.members.length, price: r4(c.price) }));
}

/**
 * Every pool of resting orders the bots care about:
 *   BSL (buy-side liquidity, above price)  /  SSL (sell-side, below price)
 * Sources: equal highs/lows, prior day/week extremes, session extremes, old swing points.
 */
function liquidity(candles, swings, atr, { tf = '15m', equalTolAtr = 0.18, maxPools = 16 } = {}) {
  const n = candles.length;
  if (!n) return { pools: [], equal_highs: [], equal_lows: [] };
  const price = candles[n - 1].c;
  const tol = Math.max((atr || price * 0.001) * equalTolAtr, price * 0.00005);

  // prior day / week extremes from the candle series
  const byDay = new Map(), byWeek = new Map();
  for (const b of candles) {
    const dk = dayKey(b.t), wk = weekKey(b.t);
    const d = byDay.get(dk) || { h: -Infinity, l: Infinity, t: b.t };
    d.h = Math.max(d.h, b.h); d.l = Math.min(d.l, b.l);
    byDay.set(dk, d);
    const w = byWeek.get(wk) || { h: -Infinity, l: Infinity, t: b.t };
    w.h = Math.max(w.h, b.h); w.l = Math.min(w.l, b.l);
    byWeek.set(wk, w);
  }
  const dayKeys = [...byDay.keys()];
  const wkKeys = [...byWeek.keys()];
  const todayKey = dayKey(Date.now());
  const thisWeek = weekKey(Date.now());
  const prevDayKeys = dayKeys.filter((k) => k < todayKey);
  const prevDay = prevDayKeys.length ? byDay.get(prevDayKeys[prevDayKeys.length - 1]) : null;
  const thisDayKey = dayKeys[dayKeys.length - 1];
  const sessionDay = byDay.get(thisDayKey);
  const prevWeek = wkKeys.filter((k) => k < thisWeek).map((k) => byWeek.get(k)).pop() || null;

  const pools = [];
  const push = (p) => { if (Number.isFinite(p.price) && p.price > 0) pools.push(p); };

  // equal highs / lows (2+ touches) — the classic "obvious" liquidity
  const highs = alternate(swings).filter((s) => s.type === 'high');
  const lows = alternate(swings).filter((s) => s.type === 'low');
  const eh = clusterLevels(highs, tol).filter((c) => c.touches >= 2);
  const el = clusterLevels(lows, tol).filter((c) => c.touches >= 2);
  for (const c of eh) push({ kind: 'equal_highs', type: 'BSL', price: c.price, touches: c.touches, t: c.lastT, label: `Equal highs ×${c.touches}`, strength: clamp(0.4 + c.touches * 0.2, 0, 1.2) });
  for (const c of el) push({ kind: 'equal_lows', type: 'SSL', price: c.price, touches: c.touches, t: c.lastT, label: `Equal lows ×${c.touches}`, strength: clamp(0.4 + c.touches * 0.2, 0, 1.2) });

  if (prevDay) {
    push({ kind: 'PDH', type: 'BSL', price: prevDay.h, t: prevDay.t, label: 'Previous day high', strength: 0.9 });
    push({ kind: 'PDL', type: 'SSL', price: prevDay.l, t: prevDay.t, label: 'Previous day low', strength: 0.9 });
  }
  if (sessionDay && sessionDay.h > -Infinity) {
    push({ kind: 'TDH', type: 'BSL', price: sessionDay.h, t: sessionDay.t, label: "Today's high", strength: 0.6 });
    push({ kind: 'TDL', type: 'SSL', price: sessionDay.l, t: sessionDay.t, label: "Today's low", strength: 0.6 });
  }
  if (prevWeek) {
    push({ kind: 'PWH', type: 'BSL', price: prevWeek.h, t: prevWeek.t, label: 'Previous week high', strength: 1.0 });
    push({ kind: 'PWL', type: 'SSL', price: prevWeek.l, t: prevWeek.t, label: 'Previous week low', strength: 1.0 });
  }
  // remaining un-swept swing extremes (old highs above, old lows below)
  for (const s of highs.slice(-4)) push({ kind: 'swing_high', type: 'BSL', price: s.price, t: s.t, label: 'Swing high', strength: 0.55, i: s.i });
  for (const s of lows.slice(-4)) push({ kind: 'swing_low', type: 'SSL', price: s.price, t: s.t, label: 'Swing low', strength: 0.55, i: s.i });

  // sort by strength, annotate side: above price = BSL, below = SSL (regardless of source)
  const merged = [];
  const seen = new Set();
  for (const p of pools.sort((a, b) => b.strength - a.strength)) {
    const key = `${p.type}:${p.price.toFixed(5)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    merged.push({
      ...p,
      side: p.price > price ? 'above' : 'below',
      distance_pct: r2(Math.abs(p.price - price) / price * 100),
      distance_atr: r2(Math.abs(p.price - price) / (atr || 1)),
      swept: false, swept_t: null,
    });
    if (merged.length >= maxPools) break;
  }
  merged.sort((a, b) => a.distance_pct - b.distance_pct);
  return {
    pools: merged,
    equal_highs: eh.map((c) => ({ price: c.price, touches: c.touches, t: c.lastT })),
    equal_lows: el.map((c) => ({ price: c.price, touches: c.touches, t: c.lastT })),
    pdh: prevDay ? r4(prevDay.h) : null, pdl: prevDay ? r4(prevDay.l) : null,
    pwh: prevWeek ? r4(prevWeek.h) : null, pwl: prevWeek ? r4(prevWeek.l) : null,
    tolerance: r4(tol), price: r4(price),
  };
}

/* ═══════════════════════════════════════════════════ 6. SWEEPS (stop hunts) */

/**
 * A sweep = a bar that trades through a liquidity level and CLOSES BACK INSIDE.
 * That is the "stop hunt / liquidity grab" the curriculum builds entries around.
 * A bar that closes through the level is a breakout, not a sweep.
 */
function findSweeps(candles, pools, atr, { lookback = 80, minWickAtr = 0.08 } = {}) {
  const n = candles.length;
  const from = Math.max(1, n - lookback);
  const out = [];
  for (let i = from; i < n; i++) {
    const b = candles[i];
    const prevClose = candles[i - 1] ? candles[i - 1].c : b.o;
    for (const p of pools) {
      // A genuine sweep runs ABOVE liquidity that was sitting above price (or below
      // liquidity that was sitting below price). Levels already on the wrong side of
      // the prior close are ordinary support/resistance, not stop runs.
      const levelAbove = p.price > prevClose;
      const levelBelow = p.price < prevClose;
      // buy-side sweep: wick above the pool, close back below it
      if (levelAbove && b.h > p.price && b.c < p.price) {
        const wick = (b.h - p.price) / (atr || 1);
        if (wick < minWickAtr) continue;
        out.push({
          i, t: b.t, type: 'BSL', dir: -1, pool: p.kind, pool_label: p.label, level: p.price,
          extreme: b.h, close: b.c, wick_atr: r2(wick), bars_ago: n - 1 - i,
          rejected_by: r2(((b.h - b.c) / (atr || 1))),
          strength: r2(clamp(wick * 1.2 + p.strength * 0.5 + (b.c < b.o ? 0.2 : 0), 0, 2)),
          label: `Swept ${p.label} at ${r4(p.price)}`,
        });
      }
      // sell-side sweep: wick below the pool, close back above it
      if (levelBelow && b.l < p.price && b.c > p.price) {
        const wick = (p.price - b.l) / (atr || 1);
        if (wick < minWickAtr) continue;
        out.push({
          i, t: b.t, type: 'SSL', dir: 1, pool: p.kind, pool_label: p.label, level: p.price,
          extreme: b.l, close: b.c, wick_atr: r2(wick), bars_ago: n - 1 - i,
          rejected_by: r2(((b.c - b.l) / (atr || 1))),
          strength: r2(clamp(wick * 1.2 + p.strength * 0.5 + (b.c > b.o ? 0.2 : 0), 0, 2)),
          label: `Swept ${p.label} at ${r4(p.price)}`,
        });
      }
    }
  }
  // strongest + most recent first, one entry per level per 4 bars (consecutive
  // bars re-testing the same pool is one event, not three)
  out.sort((a, b) => (b.strength - b.bars_ago * 0.01) - (a.strength - a.bars_ago * 0.01));
  const kept = [];
  for (const s of out) {
    const dup = kept.find((k) => k.type === s.type && Math.abs(k.level - s.level) < 1e-9 && Math.abs(k.i - s.i) <= 4);
    if (dup) continue;
    kept.push(s);
    if (kept.length >= 10) break;
  }
  return kept;
}

/* ═══════════════════════════════════════ 7. PREMIUM / DISCOUNT & DEALING RANGE */

/** Dealing range + premium/discount/equilibrium + OTE (0.62–0.79) band. */
function premiumDiscount(candles, swings) {
  const n = candles.length;
  if (!n) return null;
  const last = candles[n - 1].c;
  const highs = swings.filter((s) => s.type === 'high');
  const lows = swings.filter((s) => s.type === 'low');
  if (!highs.length || !lows.length) return null;
  // The dealing range must be a meaningful swing pair: walk back through the swings
  // until the leg spans a useful distance (>= 6 ATR) so premium/discount actually means
  // something on every timeframe. Falls back to the extremes if history is short.
  const closed = candles.slice(0, -1);
  const atrRef = I.atr(closed.length > 20 ? closed : candles, 14) || 0;
  const minSpan = atrRef * 6;
  let recentHi = highs[highs.length - 1], recentLo = lows[lows.length - 1];
  for (let back = 2; back <= Math.min(highs.length, lows.length, 8); back++) {
    const hSlice = highs.slice(-back), lSlice = lows.slice(-back);
    const h = hSlice.reduce((a, b) => (b.price > a.price ? b : a), hSlice[0]);
    const l = lSlice.reduce((a, b) => (b.price < a.price ? b : a), lSlice[0]);
    recentHi = h; recentLo = l;
    if (h.price - l.price >= minSpan) break;
  }
  const rangeHigh = recentHi.price, rangeLow = recentLo.price;
  const span = rangeHigh - rangeLow;
  if (!span) return null;
  const pos = (last - rangeLow) / span; // 0 = range low, 1 = range high
  const inDiscount = pos < 0.5, inPremium = pos > 0.5;
  const ote = pos >= 0.62 && pos <= 0.79;  // favourable long continuation zone in an uptrend
  const oteShort = pos >= 0.21 && pos <= 0.38;
  return {
    range_high: r4(rangeHigh), range_low: r4(rangeLow), mid: r4(rangeLow + span / 2),
    span: r4(span), position_pct: r2(pos * 100),
    zone: inPremium ? 'premium' : inDiscount ? 'discount' : 'equilibrium',
    ote: ote || oteShort ? (ote ? 'long' : 'short') : null,
    ote_band: [r4(rangeLow + span * 0.62), r4(rangeLow + span * 0.79)],
    levels: {
      '0': r4(rangeLow), '0.236': r4(rangeLow + span * 0.236), '0.382': r4(rangeLow + span * 0.382),
      '0.5': r4(rangeLow + span * 0.5), '0.618': r4(rangeLow + span * 0.618),
      '0.705': r4(rangeLow + span * 0.705), '0.79': r4(rangeLow + span * 0.79), '1': r4(rangeHigh),
    },
    high_t: recentHi.t, low_t: recentLo.t,
  };
}

/* ═════════════════════════════════════════════════════ 8. CRT (range theory) */

/**
 * Candle Range Theory: pick the right candle (the HTF one), mark its range, wait for
 * a sweep of one side that FAILS TO HOLD, then trade the reversal toward the other side.
 * @param {Array} htfCandles  e.g. daily candles
 * @param {Array} ltfCandles  e.g. 15m candles (used to see the sweep happen)
 */
function crt(htfCandles, ltfCandles, atr) {
  if (!htfCandles || htfCandles.length < 3) return null;
  const n = htfCandles.length;
  const target = htfCandles[n - 1];            // the "right candle" = current HTF candle
  const prevC = htfCandles[n - 2];
  const rangeHigh = target.h, rangeLow = target.l;
  const span = rangeHigh - rangeLow;
  if (!span) return null;
  const openedAt = target.t;
  const inside = (ltfCandles || []).filter((c) => c.t >= openedAt);
  if (inside.length < 3) return null;

  const price = inside[inside.length - 1].c;
  let hi = -Infinity, lo = Infinity, hiAt = null, loAt = null;
  for (const c of inside) {
    if (c.h > hi) { hi = c.h; hiAt = c.t; }
    if (c.l < lo) { lo = c.l; loAt = c.t; }
  }
  const sweptHigh = hi > rangeHigh + (atr || 0) * 0.05;
  const sweptLow = lo < rangeLow - (atr || 0) * 0.05;
  const backInsideHigh = price < rangeHigh;
  const backInsideLow = price > rangeLow;

  let setup = null;
  if (sweptHigh && backInsideHigh && !(sweptLow && backInsideLow)) {
    setup = {
      dir: -1, side: 'short', sweep_level: r4(rangeHigh), sweep_at: hiAt,
      entry: r4((rangeHigh + hi) / 2), stop: r4(hi + (atr || 0) * 0.15),
      target: r4(rangeLow + (atr || 0) * 0.15), target_label: 'opposite side of the CRT range (range low)',
      note: 'Buyside of the HTF range was swept and failed to hold — CRT expects the range low.',
    };
  } else if (sweptLow && backInsideLow && !(sweptHigh && backInsideHigh)) {
    setup = {
      dir: 1, side: 'long', sweep_level: r4(rangeLow), sweep_at: loAt,
      entry: r4((rangeLow + lo) / 2), stop: r4(lo - (atr || 0) * 0.15),
      target: r4(rangeHigh - (atr || 0) * 0.15), target_label: 'opposite side of the CRT range (range high)',
      note: 'Sellside of the HTF range was swept and failed to hold — CRT expects the range high.',
    };
  }
  if (setup) {
    const risk = Math.abs(setup.entry - setup.stop), reward = Math.abs(setup.target - setup.entry);
    setup.risk = r4(risk); setup.reward = r4(reward); setup.rr = risk ? r2(reward / risk) : 0;
    setup.hit_target_side = setup.dir > 0 ? 'range high' : 'range low';
  }

  return {
    htf_candle: { t: target.t, o: r4(target.o), h: r4(target.h), l: r4(target.l), c: r4(target.c), high_low: r2((rangeHigh - rangeLow) / rangeLow * 100) + '%' },
    prev_candle_bias: prevC.c > prevC.o ? 'bullish' : 'bearish',
    range_high: r4(rangeHigh), range_low: r4(rangeLow), mid: r4((rangeHigh + rangeLow) / 2),
    swept_high: sweptHigh, swept_low: sweptLow,
    ltf_high: r4(hi), ltf_low: r4(lo),
    back_inside: r2(((price - rangeLow) / span) * 100),
    position: price > rangeHigh ? 'above range' : price < rangeLow ? 'below range' : 'inside range',
    setup,
    steps: [
      `Right candle: current ${htfCandles === htfCandles ? 'HTF' : ''} candle ${new Date(target.t).toISOString().slice(0, 16)}Z, range ${r4(rangeLow)} – ${r4(rangeHigh)}.`,
      sweptHigh && sweptLow ? 'Both sides swept — messy, stand down until one side is reclaimed.' : sweptHigh ? 'Buyside swept' : sweptLow ? 'Sellside swept' : 'No sweep of the range yet — wait, do not front-run.',
      setup ? `Failure to hold confirmed; trading back to the ${setup.hit_target_side}.` : 'No confirmed failure to hold yet.',
    ],
  };
}

/* ═══════════════════════════════════════════════════════════ 9. KILLZONES */

const SESSIONS = [
  { key: 'sydney', name: 'Sydney', start: 21, end: 6, quality: 0.3 },
  { key: 'tokyo', name: 'Tokyo / Asia', start: 0, end: 7, quality: 0.5 },
  { key: 'london', name: 'London', start: 7, end: 12, quality: 0.85 },
  { key: 'ny_am', name: 'New York AM', start: 12, end: 16, quality: 1.0 },
  { key: 'ny_pm', name: 'New York PM', start: 16, end: 21, quality: 0.6 },
];
/** The two windows the curriculum trades hardest: London open and the 12:00–16:00 overlap. */
const SILVER_BULLETS = [
  { name: 'London killzone', startH: 6, startM: 0, endH: 9, endM: 0, quality: 1.0 },
  { name: 'NY AM killzone', startH: 12, startM: 0, endH: 15, endM: 0, quality: 1.0 },
  { name: 'NY PM killzone', startH: 15, startM: 0, endH: 18, endM: 0, quality: 0.7 },
];

function sessionState(date = new Date()) {
  const h = date.getUTCHours(), m = date.getUTCMinutes();
  const mins = h * 60 + m;
  const inWindow = (s, e) => (e > s ? mins >= s && mins < e : mins >= s || mins < e);
  const sessions = SESSIONS.map((s) => ({ ...s, active: inWindow(s.start * 60, s.end * 60), window: `${String(s.start).padStart(2, '0')}:00–${String(s.end).padStart(2, '0')}:00 UTC` }));
  const active = sessions.filter((s) => s.active);
  const open = sessions[0];
  const nextIdx = (sessions.findIndex((s) => s.active) + 1) % sessions.length;
  const bullets = SILVER_BULLETS.map((b) => {
    const s = b.startH * 60 + b.startM, e = b.endH * 60 + b.endM;
    const until = (e - mins + 1440) % 1440;
    return { name: b.name, window: `${String(b.startH).padStart(2, '0')}:${String(b.startM).padStart(2, '0')}–${String(b.endH).padStart(2, '0')}:${String(b.endM).padStart(2, '0')} UTC`, active: inWindow(s, e), minutes_to_end: inWindow(s, e) ? until : null, minutes_to_start: inWindow(s, e) ? 0 : ((s - mins + 1440) % 1440), quality: b.quality };
  });
  const activeBullet = bullets.find((b) => b.active) || null;
  return {
    now_utc: date.toISOString().slice(0, 16) + 'Z',
    active: active.length ? active.map((s) => s.name).join(' + ') : 'Between sessions',
    sessions, bullets,
    in_killzone: !!activeBullet,
    killzone: activeBullet ? activeBullet.name : null,
    quality: active ? Math.max(...active.map((s) => s.quality)) : 0.3,
    best_time: !activeBullet ? `Next high-quality window: ${bullets.filter((b) => b.minutes_to_start > 0).sort((a, b) => a.minutes_to_start - b.minutes_to_start)[0].name}` : null,
    note: activeBullet ? `${activeBullet.name} — highest-probability window for the entry models.` : 'Outside the killzones: entries here have materially lower odds. Wait for London (07:00) or the NY overlap (12:00 UTC).',
    open_session: open.name,
    next_session: { name: sessions[nextIdx].name, starts: sessions[nextIdx].window },
  };
}

/* ═══════════════════════════════════════════════════════ ANALYSE (bundle) */

/**
 * Run the full mechanics pass on one series.
 * @returns {{swings, structure, displacement, order_blocks, fvgs, breakers, liquidity, sweeps, premium_discount, crt, atr, price}}
 */
function analyse(candles, { tf = '15m', htfCandles = null } = {}) {
  const out = { ok: false, tf };
  if (!candles || candles.length < 30) { out.note = 'Not enough candles for structure analysis (need 30+).'; return out; }
  const closed = candles.slice(0, -1);
  const atr = I.atr(closed.length > 20 ? closed : candles, 14) || 0;

  const minorSwings = alternate(findSwings(candles, 2));
  const majorSwings = alternate(findSwings(candles, 5));
  const structure = marketStructure(candles, minorSwings);
  const htfStructure = majorSwings.length ? marketStructure(candles, majorSwings) : null;
  const displacement = findDisplacement(candles, atr);
  const orderBlocks = findOrderBlocks(candles, atr, displacement, structure.breaks);
  const fvgs = findFvgs(candles, atr);
  const breakers = findBreakers(orderBlocks, candles, atr);
  const liq = liquidity(candles, majorSwings.length ? majorSwings : minorSwings, atr, { tf });
  const sweeps = findSweeps(candles, liq.pools, atr);
  const pd = premiumDiscount(candles, majorSwings.length ? majorSwings : minorSwings);
  const crtRes = htfCandles ? crt(htfCandles, candles, atr) : null;

  // mark sweeps on the pool objects + flag MSS breaks
  for (const s of sweeps) {
    const pool = liq.pools.find((p) => p.kind === s.pool && Math.abs(p.price - s.level) < 1e-9);
    if (pool) { pool.swept = true; pool.swept_t = s.t; }
  }
  if (structure.last_break && structure.last_break.type === 'CHoCH') {
    const sw = sweeps.find((s) => s.bars_ago <= (structure.last_break.bars_ago || 0) + 6 && s.bars_ago >= (structure.last_break.bars_ago || 0) - 6);
    if (sw) {
      structure.last_break.mss = true;
      structure.last_break.swept = sw.pool_label;
    }
  }
  // inducement: a minor pool sitting between price and a major pool, on the way to it
  const big = liq.pools.filter((p) => p.strength >= 0.8 && !p.swept);
  const small = liq.pools.filter((p) => p.strength < 0.8 && !p.swept);
  const inducement = [];
  for (const m of big) {
    for (const s of small) {
      if (s.side !== m.side) continue;
      const closer = s.distance_pct < m.distance_pct;
      if (closer && m.distance_pct - s.distance_pct < 1.2) {
        inducement.push({ target: m.label, target_price: m.price, inducement: s.label, inducement_price: s.price, note: `Retail stops sit at the ${s.label.toLowerCase()} — expect a poke there before the run to the ${m.label.toLowerCase()}.` });
        break;
      }
    }
  }

  const price = candles[candles.length - 1].c;
  out.ok = true;
  out.price = r4(price);
  out.atr = r4(atr);
  out.swings = { minor: minorSwings.slice(-14), major: majorSwings.slice(-10) };
  out.structure = structure;
  out.htf_structure = htfStructure ? { trend: htfStructure.trend, last_break: htfStructure.last_break, recent_labels: htfStructure.recent_labels } : null;
  out.displacement = displacement.slice(-8).reverse();
  out.order_blocks = orderBlocks;
  out.fvgs = fvgs;
  out.breakers = breakers.slice(0, 6);
  out.liquidity = liq;
  out.sweeps = sweeps;
  out.premium_discount = pd;
  out.crt = crtRes;
  out.sessions = sessionState();
  out.inducement = inducement.slice(0, 4);
  out.counts = {
    swings: minorSwings.length, breaks: structure.breaks.length, displacement: displacement.length,
    order_blocks: orderBlocks.filter((z) => !z.breached).length, fvgs: fvgs.filter((g) => !g.filled).length,
    sweeps: sweeps.length, pools: liq.pools.length,
  };
  return out;
}

module.exports = {
  findSwings, alternate, marketStructure, findDisplacement, findOrderBlocks, findFvgs, findBreakers,
  liquidity, findSweeps, premiumDiscount, crt, sessionState, analyse, clusterLevels,
  SESSIONS, SILVER_BULLETS, dayKey, weekKey,
};
